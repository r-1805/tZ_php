<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Nutzungsbedingungen - northpeakstudio",
  "meta_description": "Germany"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/terms-of-service.php';
require __DIR__ . '/includes/layout.php';