<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Dienstleistungen - northpeakstudio",
  "meta_description": "Investigativer Journalismus, Online-Veröffentlichung, Nachrichtenberichterstattung"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/services.php';
require __DIR__ . '/includes/layout.php';