<?php
return json_decode(<<<'JSON'
{
  "html_lang": "de",
  "brand": "northpeakstudio",
  "brand_initials": "N",
  "footer_blurb": "Offentliche Microsite fur lokale Anfragen, nachvollziehbare Kontaktwege und rechtskonforme Hinweise im gewahlten Markt.",
  "year": 2026,
  "company": {
    "brand": "northpeakstudio",
    "brand_display": "Northpeakstudio",
    "domain": "northpeakstudio.com",
    "legal_entity_name": "Northpeakstudio GmbH",
    "email": "contact@northpeakstudio.com",
    "phone": "+49 069 4231072",
    "address": "81 Kaufingerstraße, Munich, Bavaria 20095",
    "hours": "Mo-Fr 08:00-18:00",
    "social_handles": {
      "facebook": "northpeakstudio_facebook",
      "twitter": "northpeakstudio_twitter",
      "instagram": "northpeakstudio_instagram"
    }
  },
  "tel_href": "+490694231072",
  "contact_heading": "Kontakt",
  "legal_heading": "Rechtliches",
  "cookie_title": "Cookie-Richtlinie",
  "cookie_text": "Wir nutzen notwendige Cookies und lokalen Speicher, um die Navigation stabil zu halten, Einstellungen zu speichern und Basisfunktionen zu schutzen.",
  "cookie_accept": "Akzeptieren",
  "cookie_link": "Cookie-Richtlinie lesen",
  "nav": [
    {
      "file": "index.php",
      "label": "Startseite"
    },
    {
      "file": "about.php",
      "label": "Über uns"
    },
    {
      "file": "services.php",
      "label": "Dienstleistungen"
    },
    {
      "file": "projects.php",
      "label": "Projekte"
    },
    {
      "file": "contact.php",
      "label": "Kontakt"
    }
  ],
  "legal_links": [
    {
      "file": "privacy-policy.php",
      "label": "Datenschutzrichtlinie"
    },
    {
      "file": "cookie-policy.php",
      "label": "Cookie-Richtlinie"
    },
    {
      "file": "terms-of-service.php",
      "label": "Nutzungsbedingungen"
    },
    {
      "file": "legal-notice.php",
      "label": "Impressum"
    },
    {
      "file": "disclaimer.php",
      "label": "Haftungsausschluss"
    }
  ]
}
JSON, true);
