
    <section class="legal-page">
      <div class="shell stack">
        <h1>Kontakt</h1>
        <p class="lead">Kontakt aufnehmen</p>
        <div class="grid-three">
          <article class="card">
            <h3>Northpeakstudio GmbH</h3>
            <p>81 Kaufingerstraße, Munich, Bavaria 20095</p>
            <p><a href="mailto:contact@northpeakstudio.com">contact@northpeakstudio.com</a></p>
            <p><a href="tel:+490694231072">+49 069 4231072</a></p>
            <p>Mo-Fr 08:00-18:00</p>
          </article>
          <article class="card">
            <h3>Webadresse</h3>
            <img src="/img/contact-pattern.svg" alt="Northpeakstudio" loading="lazy">
            <p>northpeakstudio.com</p>
            <h3>Markt</h3>
            <p>Deutschland</p>
            <h3>Sprache</h3>
            <p>Deutsch</p>
          </article>
          <article class="card">
            <h3>Soziale Profile</h3>
            <ul class="contact-list"><li>Facebook: @northpeakstudio_facebook</li><li>Twitter: @northpeakstudio_twitter</li><li>Instagram: @northpeakstudio_instagram</li></ul>
          </article>
        </div>
      </div>
    </section>
    