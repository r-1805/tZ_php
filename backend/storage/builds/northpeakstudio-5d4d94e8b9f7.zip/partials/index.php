
    <section class="hero">
      <div class="shell hero__grid">
        <div class="hero__main">
          <span class="kicker">Neueste Updates</span>
          <h1>Bleiben Sie informiert</h1>
          <p class="lead">Zuverlässige Berichterstattung</p>
          <div class="actions">
            <a class="btn btn--primary" href="/contact.php">Loslegen</a>
            <a class="btn btn--secondary" href="#services">Mehr erfahren</a>
          </div>
          <div class="tag-row"><span class='tag'><strong>64h</strong> Mo-Fr 08:00-18:00</span><span class='tag'><strong>6</strong> Abonnenten</span><span class='tag'><strong>92%</strong> Überblick</span></div>
        </div>
        <aside class="panel hero__visual">
          <div class="hero__visual-card">
            <img src="/img/hero-pattern.svg" alt="Northpeakstudio" loading="lazy">
          </div>
          <h3>Kontakt</h3>
          <dl>
            <div><dt>Webadresse</dt><dd>northpeakstudio.com</dd></div>
            <div><dt>E-Mail</dt><dd>contact@northpeakstudio.com</dd></div>
            <div><dt>Telefon</dt><dd>+49 069 4231072</dd></div>
            <div><dt>Adresse</dt><dd>81 Kaufingerstraße, Munich, Bavaria 20095</dd></div>
            <div><dt>Sprache</dt><dd>Deutsch</dd></div>
          </dl>
        </aside>
      </div>
    </section>
    <section class="section" id="services">
      <div class="shell">
        <div class="section__header">
          <h2>Warum uns wählen</h2>
          <p class="lead">Wir liefern Nachrichten mit Integrität</p>
        </div>
        <div class="grid-three">
            <article class="card">
              <h3>Investigativer Journalismus</h3>
              <p>Genauer Informationen</p>
            </article>
            
            <article class="card">
              <h3>Online-Veröffentlichung</h3>
              <p>Informierte Öffentlichkeit</p>
            </article>
            
            <article class="card">
              <h3>Nachrichtenberichterstattung</h3>
              <p>Gemeinschaftsengagement</p>
            </article>
            </div>
      </div>
    </section>
    <section class="section">
      <div class="shell copy">
        <div class="stack">
          <h2>Überblick</h2>
          <p>Wir liefern Nachrichten mit Integrität</p><p>Northpeakstudio begleitet Abonnenten in Deutschland mit realistischen lokalen Ablaufen und klaren Ubergaben.</p>
        </div>
        <div class="stack">
          <h2>Kontakt</h2>
          <p>Kontakt aufnehmen</p><p>Northpeakstudio GmbH arbeitet mit lokalen Kontaktdaten, einer klaren Reaktionszeit und marktspezifischer Dokumentation fur Deutschland.</p>
          <div class="tag-row tag-row--footer"><span class='tag'>Northpeakstudio GmbH</span><span class='tag'>81 Kaufingerstraße, Munich, Bavaria 20095</span><span class='tag'>Mo-Fr 08:00-18:00</span><span class='tag'>Deutsch · Deutschland</span></div>
        </div>
      </div>
    </section>
    <section class="section">
      <div class="shell">
        <div class="section__header">
          <h2>Bewertungen</h2>
        </div>
        <div class="grid-three">
            <article class="card">
              <h3>Sophie</h3>
              <p>Geschäftsführung — Northpeakstudio hält den gesamten Auftritt vom ersten Kontakt bis zur Umsetzung klar, lokal und vertrauenswürdig.</p>
            </article>
            
            <article class="card">
              <h3>Felix</h3>
              <p>Studio-Leitung — Wir wollten einen realistischen und sauberen Auftritt. Northpeakstudio hat genau das geliefert.</p>
            </article>
            
            <article class="card">
              <h3>Felix</h3>
              <p>Geschäftsführung — Northpeakstudio hält den gesamten Auftritt vom ersten Kontakt bis zur Umsetzung klar, lokal und vertrauenswürdig.</p>
            </article>
            </div>
      </div>
    </section>
    <section class="section">
      <div class="shell">
        <div class="section__header">
          <h2>FAQ</h2>
        </div>
        <div class="card"><div class='faq-item'><h3>Wie schnell kann ein neuer Auftrag starten?</h3><p>Nach Bestätigung von Umfang und Kontakten planen wir das erste Einsatzfenster in der Regel innerhalb einer Arbeitswoche.</p></div><div class='faq-item'><h3>Werden Einsatzfenster lokal abgestimmt?</h3><p>Ja. Die Planung richtet sich nach lokalen Geschäftszeiten in Deutschland, Zugängen und realistischen Reaktionsfenstern.</p></div><div class='faq-item'><h3>Kann der Leistungsumfang vor dem Start angepasst werden?</h3><p>Ja. Die Preview-Phase dient dazu, Umfang, Kontaktdaten und Dokumentation vor dem Export zu bestätigen.</p></div><div class='faq-item'><h3>Wie werden Updates nach dem Kickoff kommuniziert?</h3><p>Jeder Auftrag erhält einen klaren Kontaktweg, kurze Statusnotizen und dokumentierte nächste Schritte.</p></div></div>
      </div>
    </section>
    <section class="shell">
      <div class="cta-banner">
        <h2>Northpeakstudio</h2>
        <p>Northpeakstudio GmbH arbeitet mit lokalen Kontaktdaten, einer klaren Reaktionszeit und marktspezifischer Dokumentation fur Deutschland.</p>
        <div class="actions">
          <a class="btn btn--secondary" href="/contact.php">Loslegen</a>
        </div>
      </div>
    </section>
    