
    <section class="legal-page">
      <div class="shell stack">
        <h1>Projekte</h1>
        <p class="lead">Northpeakstudio prasentiert ein strukturiertes Leistungsbild, damit Besucher das Angebot ohne Zusatzkontext verstehen konnen.</p>
        <div class="grid-three">
            <article class="card">
              <h3>Tiefgehende Analyse</h3>
              <p>Tiefgehende Analyse wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            
            <article class="card">
              <h3>Breaking News Berichterstattung</h3>
              <p>Breaking News Berichterstattung wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            
            <article class="card">
              <h3>Gemeinschaftsgeschichten</h3>
              <p>Gemeinschaftsgeschichten wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            </div>
      </div>
    </section>
    