
    <section class="legal-page">
      <div class="shell stack">
        <h1>Dienstleistungen</h1>
        <p class="lead">Northpeakstudio prasentiert ein strukturiertes Leistungsbild, damit Besucher das Angebot ohne Zusatzkontext verstehen konnen.</p>
        <div class="grid-three">
            <article class="card">
              <h3>Investigativer Journalismus</h3>
              <p>Investigativer Journalismus wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            
            <article class="card">
              <h3>Online-Veröffentlichung</h3>
              <p>Online-Veröffentlichung wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            
            <article class="card">
              <h3>Nachrichtenberichterstattung</h3>
              <p>Nachrichtenberichterstattung wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            </div>
      </div>
    </section>
    