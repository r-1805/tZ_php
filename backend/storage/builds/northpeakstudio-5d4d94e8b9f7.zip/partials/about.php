
    <section class="legal-page">
      <div class="shell stack">
        <h1>Northpeakstudio</h1>
        <div class="copy">
          <div class="stack"><p>Wir liefern Nachrichten mit Integrität</p><p>Northpeakstudio arbeitet mit einem dokumentierten Betriebsmodell, realistischen lokalen Kontaktdaten und klaren Reaktionsfenstern.</p></div>
          <div class="stack">
            <p>Die Seitenstruktur ist auf Deutschland abgestimmt, damit Angebot, Unternehmensidentitat und Kontaktweg sofort nachvollziehbar sind.</p><p>Northpeakstudio GmbH - 81 Kaufingerstraße, Munich, Bavaria 20095</p>
            <img src="/img/footer-pattern.svg" alt="Northpeakstudio" loading="lazy">
            <ul class="contact-list"><li>Facebook: @northpeakstudio_facebook</li><li>Twitter: @northpeakstudio_twitter</li><li>Instagram: @northpeakstudio_instagram</li></ul>
          </div>
        </div>
      </div>
    </section>
    