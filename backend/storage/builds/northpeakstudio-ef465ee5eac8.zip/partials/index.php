
    <section class="hero">
      <div class="shell hero__grid">
        <div class="hero__main">
          <span class="kicker">Northpeakstudio</span>
          <h1>Northpeakstudio for United States</h1>
          <p class="lead">The public profile focuses  on House Cleanin g , and consistent business informatio n. Sparkling Clean Homes with a clear next steps for United States with consistent brandi n g, reachable contact data and clear.</p>
          <div class="actions">
            <a class="btn btn--primary" href="/contact.php">Get Started</a>
            <a class="btn btn--secondary" href="#services">Learn More</a>
          </div>
          <div class="tag-row"><span class='tag'><strong>72h</strong> Tue-Sun 10:00-20:00</span><span class='tag'><strong>12</strong> Families</span><span class='tag'><strong>99%</strong> Overview</span></div>
        </div>
        <aside class="panel hero__visual">
          <div class="hero__visual-card">
            <img src="/img/hero-pattern.svg" alt="Northpeakstudio" loading="lazy">
          </div>
          <h3>Contact</h3>
          <dl>
            <div><dt>Webadresse</dt><dd>northpeakstudio.com</dd></div>
            <div><dt>Email</dt><dd>info@northpeakstudio.com</dd></div>
            <div><dt>Phone</dt><dd>(646)385-7404</dd></div>
            <div><dt>Address</dt><dd>62129 Brian Creek, Lake Madison, NH 32257</dd></div>
            <div><dt>Language</dt><dd>English</dd></div>
          </dl>
        </aside>
      </div>
    </section>
    <section class="section" id="services">
      <div class="shell">
        <div class="section__header">
          <h2>Why Choose Us</h2>
          <p class="lead">States with consistent branding   , reachable contact data and legal pages. Northpeakstudio serves clients across United States with consistent business identity , service scope, and a clear public offer that feels locally.</p>
        </div>
        <div class="grid-three">
            <article class="card">
              <h3>Carpet Cleaning</h3>
              <p>Professional Results</p>
            </article>
            
            <article class="card">
              <h3>House Cleaning</h3>
              <p>Healthy Work Environments</p>
            </article>
            
            <article class="card">
              <h3>Office Cleaning</h3>
              <p>Sparkling Clean Homes</p>
            </article>
            </div>
      </div>
    </section>
    <section class="section">
      <div class="shell copy">
        <div class="stack">
          <h2>Overview</h2>
          <p>States with consistent branding   , reachable contact data and legal pages. Northpeakstudio serves clients across United States with consistent business identity , service scope, and a clear public offer that feels locally.</p><p>Northpeakstudio serves Families across United States with an emphasis on realistic local operations and concise handoff notes.</p>
        </div>
        <div class="stack">
          <h2>Contact</h2>
          <p>Get in Touch</p><p>Dyer-Smith operates with local contact data, a consistent response window, and market-aware documentation for United States.</p>
          <div class="tag-row tag-row--footer"><span class='tag'>Dyer-Smith</span><span class='tag'>62129 Brian Creek, Lake Madison, NH 32257</span><span class='tag'>Tue-Sun 10:00-20:00</span><span class='tag'>English · United States</span></div>
        </div>
      </div>
    </section>
    <section class="section">
      <div class="shell">
        <div class="section__header">
          <h2>Testimonials</h2>
        </div>
        <div class="grid-three">
            <article class="card">
              <h3>Morgan</h3>
              <p>Studio coordinator — We wanted something realistic and polished. Northpeakstudio delivered exactly that.</p>
            </article>
            
            <article class="card">
              <h3>Jordan</h3>
              <p>Studio coordinator — We wanted something realistic and polished. Northpeakstudio delivered exactly that.</p>
            </article>
            
            <article class="card">
              <h3>Taylor</h3>
              <p>Account manager — We wanted something realistic and polished. Northpeakstudio delivered exactly that.</p>
            </article>
            </div>
      </div>
    </section>
    <section class="section">
      <div class="shell">
        <div class="section__header">
          <h2>FAQ</h2>
        </div>
        <div class="card"><div class='faq-item'><h3>How quickly can a new engagement start?</h3><p>We usually prepare the initial operating window within one working week once the scope and contacts are confirmed.</p></div><div class='faq-item'><h3>Do you adapt service windows to local schedules?</h3><p>Yes. Scheduling is planned around United States business hours, access constraints, and realistic response windows.</p></div><div class='faq-item'><h3>Can we request a custom scope before launch?</h3><p>Yes. The preview stage is designed to confirm scope, contact details, and documentation before export.</p></div><div class='faq-item'><h3>How are updates communicated after kickoff?</h3><p>Every engagement includes a single contact route, concise status notes, and a documented next-step list.</p></div></div>
      </div>
    </section>
    <section class="shell">
      <div class="cta-banner">
        <h2>Northpeakstudio</h2>
        <p>Dyer-Smith operates with local contact data, a consistent response window, and market-aware documentation for United States.</p>
        <div class="actions">
          <a class="btn btn--secondary" href="/contact.php">Get Started</a>
        </div>
      </div>
    </section>
    