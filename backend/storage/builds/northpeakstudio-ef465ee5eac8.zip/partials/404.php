
    <section class="error-page">
      <div class="shell stack">
        <span class="kicker">404</span>
        <h1>Page not found</h1>
        <p class="lead">The page could not be found. It may have moved or the address may have changed.</p>
        <div class="actions">
          <a class="btn btn--primary" href="/index.php">Back to home</a>
        </div>
      </div>
    </section>
    