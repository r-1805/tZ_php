
    <section class="legal-page">
      <div class="shell stack">
        <h1>Services</h1>
        <p class="lead">Northpeakstudio presents a structured set of categories so visitors can review the offer without needing external context.</p>
        <div class="grid-three">
            <article class="card">
              <h3>Carpet Cleaning</h3>
              <p>Carpet Cleaning is delivered with defined milestones, market-aware wording, and realistic local coordination for United States.</p>
            </article>
            
            <article class="card">
              <h3>House Cleaning</h3>
              <p>House Cleaning is delivered with defined milestones, market-aware wording, and realistic local coordination for United States.</p>
            </article>
            
            <article class="card">
              <h3>Office Cleaning</h3>
              <p>Office Cleaning is delivered with defined milestones, market-aware wording, and realistic local coordination for United States.</p>
            </article>
            </div>
      </div>
    </section>
    