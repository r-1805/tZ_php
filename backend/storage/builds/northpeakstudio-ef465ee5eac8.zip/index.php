<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "northpeakstudio",
  "meta_description": "The public profile focuses on House Cleanin g , and consistent business informatio n. Sparkling Clean Homes with a clear next steps for United States with consi"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/index.php';
require __DIR__ . '/includes/layout.php';