<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Services - northpeakstudio",
  "meta_description": "Carpet Cleaning, House Cleaning, Office Cleaning"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/services.php';
require __DIR__ . '/includes/layout.php';