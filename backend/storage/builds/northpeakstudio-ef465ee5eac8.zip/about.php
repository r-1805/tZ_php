<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "About - northpeakstudio",
  "meta_description": "States with consistent branding , reachable contact data and legal pages. Northpeakstudio serves clients across United States with consistent business identity "
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/about.php';
require __DIR__ . '/includes/layout.php';