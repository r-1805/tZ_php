
    <section class="legal-page">
      <div class="shell stack">
        <h1>Kontakt</h1>
        <p class="lead">Kontaktieren Sie uns für Zeitpläne, Angebote und Onboarding-Details.</p>
        <div class="grid-three">
          <article class="card">
            <h3>Northpeakstudio GmbH</h3>
            <p>81 Maximilianstraße, Munich, Bavaria 10115</p>
            <p><a href="mailto:contact@northpeakstudio.com">contact@northpeakstudio.com</a></p>
            <p><a href="tel:+49404231072">+49 40 423 1072</a></p>
            <p>Mo-Sa 09:00-19:00</p>
          </article>
          <article class="card">
            <h3>Webadresse</h3>
            <img src="/img/contact-pattern.svg" alt="Northpeakstudio" loading="lazy">
            <p>northpeakstudio.com</p>
            <h3>Markt</h3>
            <p>Deutschland</p>
            <h3>Sprache</h3>
            <p>Deutsch</p>
          </article>
          <article class="card">
            <h3>Soziale Profile</h3>
            <ul class="contact-list"><li>Linkedin: @northpeakstudio_linkedin</li><li>Instagram: @northpeakstudio_instagram</li><li>Facebook: @northpeakstudio_facebook</li></ul>
          </article>
        </div>
      </div>
    </section>
    