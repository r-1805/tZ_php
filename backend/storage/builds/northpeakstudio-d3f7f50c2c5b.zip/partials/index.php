
    <section class="hero">
      <div class="shell hero__grid">
        <div class="hero__main">
          <span class="kicker">Newsroom-Rhythmus</span>
          <h1>Ein modernes Publikationsformat für prägnante Berichte, Erklärstücke und Themenupdates.</h1>
          <p class="lead">Die Berichterstattung ist um wiederkehrende Beats, Themenseiten und ein zugängliches Archiv organisiert.</p>
          <div class="actions">
            <a class="btn btn--primary" href="/contact.php">Beratung anfragen</a>
            <a class="btn btn--secondary" href="#services">Vorgehensweise ansehen</a>
          </div>
          <div class="tag-row"><span class='tag'><strong>64h</strong> Mo-Sa 09:00-19:00</span><span class='tag'><strong>6</strong> Pressekontakte</span><span class='tag'><strong>92%</strong> Überblick</span></div>
        </div>
        <aside class="panel hero__visual">
          <div class="hero__visual-card">
            <img src="/img/hero-pattern.svg" alt="Northpeakstudio" loading="lazy">
          </div>
          <h3>Kontakt</h3>
          <dl>
            <div><dt>Webadresse</dt><dd>northpeakstudio.com</dd></div>
            <div><dt>E-Mail</dt><dd>contact@northpeakstudio.com</dd></div>
            <div><dt>Telefon</dt><dd>+49 40 423 1072</dd></div>
            <div><dt>Adresse</dt><dd>81 Maximilianstraße, Munich, Bavaria 10115</dd></div>
            <div><dt>Sprache</dt><dd>Deutsch</dd></div>
          </dl>
        </aside>
      </div>
    </section>
    <section class="section" id="services">
      <div class="shell">
        <div class="section__header">
          <h2>Warum Teams uns wählen</h2>
          <p class="lead">Das Newsroom-Modell setzt auf strukturierte Ressorts, transparente Quellenarbeit und klare Verantwortlichkeiten.</p>
        </div>
        <div class="grid-three">
            <article class="card">
              <h3>Meinung und Analyse</h3>
              <p>Redaktionelle Übergaben mit weniger Produktionsreibung.</p>
            </article>
            
            <article class="card">
              <h3>Newsletter-Planung</h3>
              <p>Ein konsistenter Rhythmus über Meldungen, Erklärstücke und Follow-ups.</p>
            </article>
            
            <article class="card">
              <h3>Erklärende Langformate</h3>
              <p>Themenhubs für einfache Archivnavigation.</p>
            </article>
            </div>
      </div>
    </section>
    <section class="section">
      <div class="shell copy">
        <div class="stack">
          <h2>Überblick</h2>
          <p>Das Newsroom-Modell setzt auf strukturierte Ressorts, transparente Quellenarbeit und klare Verantwortlichkeiten.</p><p>Northpeakstudio begleitet Pressekontakte in Deutschland mit realistischen lokalen Ablaufen und klaren Ubergaben.</p>
        </div>
        <div class="stack">
          <h2>Kontakt</h2>
          <p>Kontaktieren Sie uns für Zeitpläne, Angebote und Onboarding-Details.</p><p>Northpeakstudio GmbH arbeitet mit lokalen Kontaktdaten, einer klaren Reaktionszeit und marktspezifischer Dokumentation fur Deutschland.</p>
          <div class="tag-row tag-row--footer"><span class='tag'>Northpeakstudio GmbH</span><span class='tag'>81 Maximilianstraße, Munich, Bavaria 10115</span><span class='tag'>Mo-Sa 09:00-19:00</span><span class='tag'>Deutsch · Deutschland</span></div>
        </div>
      </div>
    </section>
    <section class="section">
      <div class="shell">
        <div class="section__header">
          <h2>Kundenstimmen</h2>
        </div>
        <div class="grid-three">
            <article class="card">
              <h3>Sophie</h3>
              <p>Geschäftsführung — Northpeakstudio hält den gesamten Auftritt vom ersten Kontakt bis zur Umsetzung klar, lokal und vertrauenswürdig.</p>
            </article>
            
            <article class="card">
              <h3>Felix</h3>
              <p>Studio-Leitung — Wir wollten einen realistischen und sauberen Auftritt. Northpeakstudio hat genau das geliefert.</p>
            </article>
            
            <article class="card">
              <h3>Felix</h3>
              <p>Geschäftsführung — Northpeakstudio hält den gesamten Auftritt vom ersten Kontakt bis zur Umsetzung klar, lokal und vertrauenswürdig.</p>
            </article>
            </div>
      </div>
    </section>
    <section class="section">
      <div class="shell">
        <div class="section__header">
          <h2>Häufige Fragen</h2>
        </div>
        <div class="card"><div class='faq-item'><h3>Wie schnell kann ein neuer Auftrag starten?</h3><p>Nach Bestätigung von Umfang und Kontakten planen wir das erste Einsatzfenster in der Regel innerhalb einer Arbeitswoche.</p></div><div class='faq-item'><h3>Werden Einsatzfenster lokal abgestimmt?</h3><p>Ja. Die Planung richtet sich nach lokalen Geschäftszeiten in Deutschland, Zugängen und realistischen Reaktionsfenstern.</p></div><div class='faq-item'><h3>Kann der Leistungsumfang vor dem Start angepasst werden?</h3><p>Ja. Die Preview-Phase dient dazu, Umfang, Kontaktdaten und Dokumentation vor dem Export zu bestätigen.</p></div><div class='faq-item'><h3>Wie werden Updates nach dem Kickoff kommuniziert?</h3><p>Jeder Auftrag erhält einen klaren Kontaktweg, kurze Statusnotizen und dokumentierte nächste Schritte.</p></div></div>
      </div>
    </section>
    <section class="shell">
      <div class="cta-banner">
        <h2>Northpeakstudio</h2>
        <p>Northpeakstudio GmbH arbeitet mit lokalen Kontaktdaten, einer klaren Reaktionszeit und marktspezifischer Dokumentation fur Deutschland.</p>
        <div class="actions">
          <a class="btn btn--secondary" href="/contact.php">Beratung anfragen</a>
        </div>
      </div>
    </section>
    