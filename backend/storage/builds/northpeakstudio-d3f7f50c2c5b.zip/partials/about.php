
    <section class="legal-page">
      <div class="shell stack">
        <h1>Northpeakstudio</h1>
        <div class="copy">
          <div class="stack"><p>Das Newsroom-Modell setzt auf strukturierte Ressorts, transparente Quellenarbeit und klare Verantwortlichkeiten.</p><p>Northpeakstudio arbeitet mit einem dokumentierten Betriebsmodell, realistischen lokalen Kontaktdaten und klaren Reaktionsfenstern.</p></div>
          <div class="stack">
            <p>Die Seitenstruktur ist auf Deutschland abgestimmt, damit Angebot, Unternehmensidentitat und Kontaktweg sofort nachvollziehbar sind.</p><p>Northpeakstudio GmbH - 81 Maximilianstraße, Munich, Bavaria 10115</p>
            <img src="/img/footer-pattern.svg" alt="Northpeakstudio" loading="lazy">
            <ul class="contact-list"><li>Linkedin: @northpeakstudio_linkedin</li><li>Instagram: @northpeakstudio_instagram</li><li>Facebook: @northpeakstudio_facebook</li></ul>
          </div>
        </div>
      </div>
    </section>
    