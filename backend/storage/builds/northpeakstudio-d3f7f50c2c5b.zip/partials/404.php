
    <section class="error-page">
      <div class="shell stack">
        <span class="kicker">404</span>
        <h1>Die angeforderte Seite ist nicht verfügbar.</h1>
        <p class="lead">Wir verwenden notwendige Cookies, damit diese Website sicher und reaktionsschnell bleibt. Details finden Sie jederzeit in der Cookie-Richtlinie.</p>
        <div class="actions">
          <a class="btn btn--primary" href="/index.php">Zur Startseite</a>
        </div>
      </div>
    </section>
    