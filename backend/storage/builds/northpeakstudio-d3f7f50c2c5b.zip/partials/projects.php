
    <section class="legal-page">
      <div class="shell stack">
        <h1>Projekte</h1>
        <p class="lead">Northpeakstudio prasentiert ein strukturiertes Leistungsbild, damit Besucher das Angebot ohne Zusatzkontext verstehen konnen.</p>
        <div class="grid-three">
            <article class="card">
              <h3>City Business Watch</h3>
              <p>City Business Watch wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            
            <article class="card">
              <h3>Wahl-Update-Desk</h3>
              <p>Wahl-Update-Desk wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            
            <article class="card">
              <h3>Wöchentlicher Policy-Digest</h3>
              <p>Wöchentlicher Policy-Digest wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            </div>
      </div>
    </section>
    