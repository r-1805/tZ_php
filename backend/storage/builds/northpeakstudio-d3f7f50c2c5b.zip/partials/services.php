
    <section class="legal-page">
      <div class="shell stack">
        <h1>Leistungen</h1>
        <p class="lead">Northpeakstudio prasentiert ein strukturiertes Leistungsbild, damit Besucher das Angebot ohne Zusatzkontext verstehen konnen.</p>
        <div class="grid-three">
            <article class="card">
              <h3>Meinung und Analyse</h3>
              <p>Meinung und Analyse wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            
            <article class="card">
              <h3>Newsletter-Planung</h3>
              <p>Newsletter-Planung wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            
            <article class="card">
              <h3>Erklärende Langformate</h3>
              <p>Erklärende Langformate wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            </div>
      </div>
    </section>
    