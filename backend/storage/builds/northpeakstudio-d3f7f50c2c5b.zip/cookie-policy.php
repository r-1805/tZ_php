<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Cookie-Richtlinie - northpeakstudio",
  "meta_description": "laws of Germany and, where required, directly applicable EU legislation"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/cookie-policy.php';
require __DIR__ . '/includes/layout.php';