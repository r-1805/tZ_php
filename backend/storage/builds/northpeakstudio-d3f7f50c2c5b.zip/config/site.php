<?php
return json_decode(<<<'JSON'
{
  "html_lang": "de",
  "brand": "northpeakstudio",
  "brand_initials": "N",
  "footer_blurb": "Unabhängige, strukturierte Teams mit klaren Leistungsseiten und glaubwürdigen lokalen Kontaktdaten.",
  "year": 2026,
  "company": {
    "brand": "northpeakstudio",
    "brand_display": "Northpeakstudio",
    "domain": "northpeakstudio.com",
    "legal_entity_name": "Northpeakstudio GmbH",
    "email": "contact@northpeakstudio.com",
    "phone": "+49 40 423 1072",
    "address": "81 Maximilianstraße, Munich, Bavaria 10115",
    "hours": "Mo-Sa 09:00-19:00",
    "social_handles": {
      "linkedin": "northpeakstudio_linkedin",
      "instagram": "northpeakstudio_instagram",
      "facebook": "northpeakstudio_facebook"
    }
  },
  "tel_href": "+49404231072",
  "contact_heading": "Kontakt",
  "legal_heading": "Rechtliches",
  "cookie_title": "Cookie-Einstellungen",
  "cookie_text": "Wir verwenden notwendige Cookies, damit diese Website sicher und reaktionsschnell bleibt. Details finden Sie jederzeit in der Cookie-Richtlinie.",
  "cookie_accept": "Akzeptieren",
  "cookie_link": "Cookie-Richtlinie lesen",
  "nav": [
    {
      "file": "index.php",
      "label": "Start"
    },
    {
      "file": "about.php",
      "label": "Über uns"
    },
    {
      "file": "services.php",
      "label": "Leistungen"
    },
    {
      "file": "projects.php",
      "label": "Projekte"
    },
    {
      "file": "contact.php",
      "label": "Kontakt"
    }
  ],
  "legal_links": [
    {
      "file": "privacy-policy.php",
      "label": "Datenschutzerklärung"
    },
    {
      "file": "cookie-policy.php",
      "label": "Cookie-Richtlinie"
    },
    {
      "file": "terms-of-service.php",
      "label": "Nutzungsbedingungen"
    },
    {
      "file": "legal-notice.php",
      "label": "Impressum"
    },
    {
      "file": "disclaimer.php",
      "label": "Haftungsausschluss"
    }
  ]
}
JSON, true);
