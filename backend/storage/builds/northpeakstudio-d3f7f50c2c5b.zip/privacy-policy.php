<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Datenschutzerklärung - northpeakstudio",
  "meta_description": "laws of Germany and, where required, directly applicable EU legislation"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/privacy-policy.php';
require __DIR__ . '/includes/layout.php';