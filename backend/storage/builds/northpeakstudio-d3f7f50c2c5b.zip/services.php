<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Leistungen - northpeakstudio",
  "meta_description": "Meinung und Analyse, Newsletter-Planung, Erklärende Langformate"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/services.php';
require __DIR__ . '/includes/layout.php';