<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Projekte - northpeakstudio",
  "meta_description": "City Business Watch, Wahl-Update-Desk, Wöchentlicher Policy-Digest"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/projects.php';
require __DIR__ . '/includes/layout.php';