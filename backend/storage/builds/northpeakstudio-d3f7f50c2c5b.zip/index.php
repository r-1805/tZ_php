<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "northpeakstudio",
  "meta_description": "Die Berichterstattung ist um wiederkehrende Beats, Themenseiten und ein zugängliches Archiv organisiert."
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/index.php';
require __DIR__ . '/includes/layout.php';