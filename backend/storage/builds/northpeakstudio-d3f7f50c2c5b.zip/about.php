<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Über uns - northpeakstudio",
  "meta_description": "Das Newsroom-Modell setzt auf strukturierte Ressorts, transparente Quellenarbeit und klare Verantwortlichkeiten."
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/about.php';
require __DIR__ . '/includes/layout.php';