<?php
return json_decode(<<<'JSON'
{
  "html_lang": "en",
  "brand": "northpeakstudio",
  "brand_initials": "N",
  "footer_blurb": "Independent, detail-oriented teams delivering clear service pages and realistic local contact information.",
  "year": 2026,
  "company": {
    "brand": "northpeakstudio",
    "brand_display": "Northpeakstudio",
    "domain": "northpeakstudio.com",
    "legal_entity_name": "Northpeakstudio Ltd",
    "email": "contact@northpeakstudio.com",
    "phone": "+44 131 859 3046",
    "address": "137 George Street, Edinburgh, Scotland B1 1AA",
    "hours": "Mon-Fri 08:00-18:00",
    "social_handles": {
      "linkedin": "northpeakstudio_linkedin",
      "instagram": "northpeakstudio_instagram",
      "facebook": "northpeakstudio_facebook"
    }
  },
  "tel_href": "+441318593046",
  "contact_heading": "Contact",
  "legal_heading": "Legal",
  "cookie_title": "Cookie preferences",
  "cookie_text": "We use essential cookies to keep this site responsive and secure. You can review how cookies are used at any time.",
  "cookie_accept": "Accept",
  "cookie_link": "Read cookie policy",
  "nav": [
    {
      "file": "index.php",
      "label": "Home"
    },
    {
      "file": "about.php",
      "label": "About"
    },
    {
      "file": "offerings.php",
      "label": "Offerings"
    },
    {
      "file": "portfolio.php",
      "label": "Portfolio"
    },
    {
      "file": "contact.php",
      "label": "Contact"
    }
  ],
  "legal_links": [
    {
      "file": "privacy-policy.php",
      "label": "Privacy Policy"
    },
    {
      "file": "cookie-policy.php",
      "label": "Cookie Policy"
    },
    {
      "file": "terms-of-service.php",
      "label": "Terms of Service"
    },
    {
      "file": "legal-notice.php",
      "label": "Legal Notice"
    },
    {
      "file": "disclaimer.php",
      "label": "Disclaimer"
    }
  ]
}
JSON, true);
