<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Legal Notice - northpeakstudio",
  "meta_description": "Information Commissioner's Office"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/legal-notice.php';
require __DIR__ . '/includes/layout.php';