
    <section class="hero">
      <div class="shell hero__grid">
        <div class="hero__main">
          <span class="kicker">Campaign systems</span>
          <h1>Strategic campaign execution built for measurable acquisition and retention.</h1>
          <p class="lead">We connect paid media, landing pages, and reporting loops into one accountable workflow.</p>
          <div class="actions">
            <a class="btn btn--primary" href="/contact.php">Request a consultation</a>
            <a class="btn btn--secondary" href="#services">View our approach</a>
          </div>
          <div class="tag-row"><span class='tag'><strong>60h</strong> Mon-Fri 08:00-18:00</span><span class='tag'><strong>11</strong> founders</span><span class='tag'><strong>99%</strong> Overview</span></div>
        </div>
        <aside class="panel hero__visual">
          <div class="hero__visual-card">
            <img src="/img/hero-pattern.svg" alt="Northpeakstudio" loading="lazy">
          </div>
          <h3>Contact</h3>
          <dl>
            <div><dt>Webadresse</dt><dd>northpeakstudio.com</dd></div>
            <div><dt>Email</dt><dd>contact@northpeakstudio.com</dd></div>
            <div><dt>Phone</dt><dd>+44 131 859 3046</dd></div>
            <div><dt>Address</dt><dd>137 George Street, Edinburgh, Scotland B1 1AA</dd></div>
            <div><dt>Language</dt><dd>English</dd></div>
          </dl>
        </aside>
      </div>
    </section>
    <section class="section" id="services">
      <div class="shell">
        <div class="section__header">
          <h2>Why teams choose us</h2>
          <p class="lead">Every sprint ends with decision notes, next-step experiments, and reporting that stakeholders can actually use.</p>
        </div>
        <div class="grid-three">
            <article class="card">
              <h3>Funnel messaging design</h3>
              <p>Creative testing with faster decision cycles.</p>
            </article>
            
            <article class="card">
              <h3>Lifecycle automation</h3>
              <p>Reporting built around weekly operating signals.</p>
            </article>
            
            <article class="card">
              <h3>Landing page optimization</h3>
              <p>Channel plans tied to targets and budget logic.</p>
            </article>
            </div>
      </div>
    </section>
    <section class="section">
      <div class="shell copy">
        <div class="stack">
          <h2>Overview</h2>
          <p>Every sprint ends with decision notes, next-step experiments, and reporting that stakeholders can actually use.</p><p>Northpeakstudio serves founders across United Kingdom with an emphasis on realistic local operations and concise handoff notes.</p>
        </div>
        <div class="stack">
          <h2>Contact</h2>
          <p>Reach out for timelines, quotes, and onboarding details.</p><p>Northpeakstudio Ltd operates with local contact data, a consistent response window, and market-aware documentation for United Kingdom.</p>
          <div class="tag-row tag-row--footer"><span class='tag'>Northpeakstudio Ltd</span><span class='tag'>137 George Street, Edinburgh, Scotland B1 1AA</span><span class='tag'>Mon-Fri 08:00-18:00</span><span class='tag'>English · United Kingdom</span></div>
        </div>
      </div>
    </section>
    <section class="section">
      <div class="shell">
        <div class="section__header">
          <h2>Client perspective</h2>
        </div>
        <div class="grid-three">
            <article class="card">
              <h3>Morgan</h3>
              <p>Account manager — The site makes the offer, contact path, and business identity feel consistent across every page.</p>
            </article>
            
            <article class="card">
              <h3>Morgan</h3>
              <p>Founder — We wanted something realistic and polished. Northpeakstudio delivered exactly that.</p>
            </article>
            
            <article class="card">
              <h3>Avery</h3>
              <p>Studio coordinator — We wanted something realistic and polished. Northpeakstudio delivered exactly that.</p>
            </article>
            </div>
      </div>
    </section>
    <section class="section">
      <div class="shell">
        <div class="section__header">
          <h2>Frequently asked questions</h2>
        </div>
        <div class="card"><div class='faq-item'><h3>How quickly can a new engagement start?</h3><p>We usually prepare the initial operating window within one working week once the scope and contacts are confirmed.</p></div><div class='faq-item'><h3>Do you adapt service windows to local schedules?</h3><p>Yes. Scheduling is planned around United Kingdom business hours, access constraints, and realistic response windows.</p></div><div class='faq-item'><h3>Can we request a custom scope before launch?</h3><p>Yes. The preview stage is designed to confirm scope, contact details, and documentation before export.</p></div><div class='faq-item'><h3>How are updates communicated after kickoff?</h3><p>Every engagement includes a single contact route, concise status notes, and a documented next-step list.</p></div></div>
      </div>
    </section>
    <section class="shell">
      <div class="cta-banner">
        <h2>Northpeakstudio</h2>
        <p>Northpeakstudio Ltd operates with local contact data, a consistent response window, and market-aware documentation for United Kingdom.</p>
        <div class="actions">
          <a class="btn btn--secondary" href="/contact.php">Request a consultation</a>
        </div>
      </div>
    </section>
    