
    <section class="error-page">
      <div class="shell stack">
        <span class="kicker">404</span>
        <h1>The page you requested is unavailable.</h1>
        <p class="lead">We use essential cookies to keep this site responsive and secure. You can review how cookies are used at any time.</p>
        <div class="actions">
          <a class="btn btn--primary" href="/index.php">Back to home</a>
        </div>
      </div>
    </section>
    