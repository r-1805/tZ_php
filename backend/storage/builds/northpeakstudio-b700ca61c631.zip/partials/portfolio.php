
    <section class="legal-page">
      <div class="shell stack">
        <h1>Portfolio</h1>
        <p class="lead">Northpeakstudio presents a structured set of categories so visitors can review the offer without needing external context.</p>
        <div class="grid-three">
            <article class="card">
              <h3>Regional multi-channel launch</h3>
              <p>Regional multi-channel launch is delivered with defined milestones, market-aware wording, and realistic local coordination for United Kingdom.</p>
            </article>
            
            <article class="card">
              <h3>Creative performance recovery</h3>
              <p>Creative performance recovery is delivered with defined milestones, market-aware wording, and realistic local coordination for United Kingdom.</p>
            </article>
            
            <article class="card">
              <h3>B2B lead generation relaunch</h3>
              <p>B2B lead generation relaunch is delivered with defined milestones, market-aware wording, and realistic local coordination for United Kingdom.</p>
            </article>
            </div>
      </div>
    </section>
    