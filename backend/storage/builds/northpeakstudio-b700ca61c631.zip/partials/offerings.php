
    <section class="legal-page">
      <div class="shell stack">
        <h1>Offerings</h1>
        <p class="lead">Northpeakstudio presents a structured set of categories so visitors can review the offer without needing external context.</p>
        <div class="grid-three">
            <article class="card">
              <h3>Funnel messaging design</h3>
              <p>Funnel messaging design is delivered with defined milestones, market-aware wording, and realistic local coordination for United Kingdom.</p>
            </article>
            
            <article class="card">
              <h3>Lifecycle automation</h3>
              <p>Lifecycle automation is delivered with defined milestones, market-aware wording, and realistic local coordination for United Kingdom.</p>
            </article>
            
            <article class="card">
              <h3>Landing page optimization</h3>
              <p>Landing page optimization is delivered with defined milestones, market-aware wording, and realistic local coordination for United Kingdom.</p>
            </article>
            </div>
      </div>
    </section>
    