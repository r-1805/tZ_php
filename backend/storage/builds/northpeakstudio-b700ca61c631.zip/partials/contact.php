
    <section class="legal-page">
      <div class="shell stack">
        <h1>Contact</h1>
        <p class="lead">Reach out for timelines, quotes, and onboarding details.</p>
        <div class="grid-three">
          <article class="card">
            <h3>Northpeakstudio Ltd</h3>
            <p>137 George Street, Edinburgh, Scotland B1 1AA</p>
            <p><a href="mailto:contact@northpeakstudio.com">contact@northpeakstudio.com</a></p>
            <p><a href="tel:+441318593046">+44 131 859 3046</a></p>
            <p>Mon-Fri 08:00-18:00</p>
          </article>
          <article class="card">
            <h3>Webadresse</h3>
            <img src="/img/contact-pattern.svg" alt="Northpeakstudio" loading="lazy">
            <p>northpeakstudio.com</p>
            <h3>Market</h3>
            <p>United Kingdom</p>
            <h3>Language</h3>
            <p>English</p>
          </article>
          <article class="card">
            <h3>Social profiles</h3>
            <ul class="contact-list"><li>Linkedin: @northpeakstudio_linkedin</li><li>Instagram: @northpeakstudio_instagram</li><li>Facebook: @northpeakstudio_facebook</li></ul>
          </article>
        </div>
      </div>
    </section>
    