<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Portfolio - northpeakstudio",
  "meta_description": "Regional multi-channel launch, Creative performance recovery, B2B lead generation relaunch"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/portfolio.php';
require __DIR__ . '/includes/layout.php';