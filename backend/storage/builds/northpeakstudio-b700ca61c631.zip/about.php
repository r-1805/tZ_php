<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "About - northpeakstudio",
  "meta_description": "Every sprint ends with decision notes, next-step experiments, and reporting that stakeholders can actually use."
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/about.php';
require __DIR__ . '/includes/layout.php';