<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Offerings - northpeakstudio",
  "meta_description": "Funnel messaging design, Lifecycle automation, Landing page optimization"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/offerings.php';
require __DIR__ . '/includes/layout.php';