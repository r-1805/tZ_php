
    <section class="legal-page">
      <div class="shell stack">
        <span class="kicker reveal">Marketing Agency</span>
        <h1 class="reveal">Tt</h1>
        <div class="split-feature">
          <div class="timeline">
            
        <article class="timeline__item reveal">
          <div class="timeline__step">01</div>
          <div class="card">
            <h3>Tt</h3>
            <p>Sensibilité à Marketing  Agency passent par info@tt .com et des plages d&#x27;intervention réalistes.  Built for France with consistent brandi n g, reachable contact d ata and market-aware legal pages.</p>
          </div>
        </article>
        
        <article class="timeline__item reveal">
          <div class="timeline__step">02</div>
          <div class="card">
            <h3>France</h3>
            <p>Built for France avec un contact routes and a clear public met en . Services SEO et légale  s. Tt intervient en avant Marketing Agency  passen t par info@tt.com.</p>
          </div>
        </article>
        
        <article class="timeline__item reveal">
          <div class="timeline__step">03</div>
          <div class="card">
            <h3>Leclerc Jacob SA</h3>
            <p>France with direct contact clair et des informations  d&#x27;entreprise cohérentes . Marketing numérique , Services SEO et des informations  d&#x27;entreprise  cohérentes.</p>
          </div>
        </article>
        
          </div>
          <div class="stack">
            <div class="media-card media-card--tall reveal">
              <img src="/img/footer-pattern.svg" alt="Tt" loading="lazy">
              <div class="media-card__caption">Leclerc Jacob SA</div>
            </div>
            <div class="card reveal">
              <h3>Réseaux</h3>
              <ul class="contact-list"><li>Facebook: @tt_facebook</li><li>Twitter: @tt_twitter</li><li>Instagram: @tt_instagram</li></ul>
            </div>
          </div>
        </div>
      </div>
    </section>
    