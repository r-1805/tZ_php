
    <section class="error-page">
      <div class="shell stack">
        <span class="kicker">404</span>
        <h1>Page introuvable</h1>
        <p class="lead">La page est introuvable. Elle a peut-être été déplacée ou l&#x27;adresse a changé.</p>
        <div class="actions">
          <a class="btn btn--primary" href="/index.php">Retour a l&#x27;accueil</a>
        </div>
      </div>
    </section>
    