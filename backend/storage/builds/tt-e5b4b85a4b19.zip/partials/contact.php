
    <section class="legal-page">
      <div class="shell stack">
        <span class="kicker reveal">France</span>
        <h1 class="reveal">Contact</h1>
        <p class="lead reveal">Entrer en contact</p>
        <div class="contact-shell">
          <article class="card reveal">
            <h3>Leclerc Jacob SA</h3>
            <dl class="contact-grid">
              <div><dt>Adresse</dt><dd>514, boulevard Masse, 29708 Ollivier-sur-Clerc</dd></div>
              <div><dt>Téléphone</dt><dd><a href="tel:+33011982560">+33 01 198 2560</a></dd></div>
              <div><dt>Email</dt><dd><a href="mailto:info@tt.com">info@tt.com</a></dd></div>
              <div><dt>Langue</dt><dd>Français</dd></div>
            </dl>
            <div class="actions">
              <a class="btn btn--primary" href="/contact.php">Commencer</a>
            </div>
          </article>
          <div class="stack">
            <article class="media-card reveal">
              <img src="/img/contact-pattern.svg" alt="Tt" loading="lazy">
              <div class="media-card__caption">tt.com</div>
            </article>
            <article class="card reveal">
              <h3>Réseaux</h3>
              <ul class="contact-list"><li>Facebook: @tt_facebook</li><li>Twitter: @tt_twitter</li><li>Instagram: @tt_instagram</li></ul>
            </article>
          </div>
        </div>
      </div>
    </section>
    