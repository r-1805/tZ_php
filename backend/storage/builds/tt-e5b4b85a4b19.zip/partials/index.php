
    <section class="hero">
      <div class="shell hero__grid">
        <div class="hero__main reveal">
          <span class="kicker">France</span>
          <h1>Marketing Agency microsite for France</h1>
          <p class="lead">France  with consistent brandin g , reachable contact cla ir et des informations d&#x27;entreprise cohérentes . France with realistic local contact data and clear next steps for Fran ce avec un contact data and.</p>
          <div class="actions">
            <a class="btn btn--primary" href="/contact.php">Commencer</a>
            <a class="btn btn--secondary" href="#services">En savoir plus</a>
          </div>
          <div class="tag-row"><span class='tag'><strong>47h</strong> Lun-Ven 08:00-18:00</span><span class='tag'><strong>3</strong> Petites entreprises</span><span class='tag'><strong>89%</strong> Aperçu</span></div>
          <div class="metrics-band"><article class='metric-card reveal'><strong>47h</strong><span class='muted'>Lun-Ven 08:00-18:00</span></article><article class='metric-card reveal'><strong>3</strong><span class='muted'>Petites entreprises</span></article><article class='metric-card reveal'><strong>89%</strong><span class='muted'>Aperçu</span></article></div>
        </div>
        <aside class="hero__support">
          <div class="media-card media-card--tall reveal">
            <img src="/img/hero-pattern.svg" alt="Tt" loading="lazy">
            <div class="media-card__caption">
              <strong>Tt</strong>
              <div>France</div>
            </div>
          </div>
          <div class="panel reveal">
            <h3>Contact</h3>
            <dl class="contact-grid">
              <div><dt>Domaine</dt><dd>tt.com</dd></div>
              <div><dt>Email</dt><dd>info@tt.com</dd></div>
              <div><dt>Téléphone</dt><dd>+33 01 198 2560</dd></div>
              <div><dt>Adresse</dt><dd>514, boulevard Masse, 29708 Ollivier-sur-Clerc</dd></div>
              <div><dt>Langue</dt><dd>Français</dd></div>
            </dl>
          </div>
        </aside>
      </div>
    </section>
    <section class="section section--spacious" id="services">
      <div class="shell">
        <div class="section__header">
          <span class="kicker section__eyebrow reveal">Pourquoi nous choisir</span>
          <h2>Pourquoi nous choisir</h2>
          <p class="lead">Sensibilité à Marketing  Agency passent par info@tt .com et des plages d&#x27;intervention réalistes.  Built for France with consistent brandi n g, reachable contact d ata and market-aware legal pages.</p>
        </div>
        <div class="grid-three">
            <article class="card reveal">
              <h3>Services SEO</h3>
              <p>ROI amélioré</p>
            </article>
            
            <article class="card reveal">
              <h3>Marketing sur les réseaux sociaux</h3>
              <p>Trafic web plus élevé</p>
            </article>
            
            <article class="card reveal">
              <h3>Marketing numérique</h3>
              <p>Sensibilité à la marque accrue</p>
            </article>
            </div>
      </div>
    </section>
    <section class="section section--spacious">
      <div class="shell split-feature">
        <div class="stack reveal">
          <h2>Aperçu</h2>
          <p>Sensibilité à Marketing  Agency passent par info@tt .com et des plages d&#x27;intervention réalistes.  Built for France with consistent brandi n g, reachable contact d ata and market-aware legal pages.</p><p>Tt accompagne Petites entreprises en France avec une organisation locale realiste et des notes de transmission claires.</p>
          <ul class="list-checks"><li>Services SEO</li><li>Marketing sur les réseaux sociaux</li><li>Marketing numérique</li></ul>
        </div>
        <div class="gallery-strip">
          <div class="media-card reveal">
            <img src="/img/contact-pattern.svg" alt="Tt" loading="lazy">
            <div class="media-card__caption">Leclerc Jacob SA</div>
          </div>
          <div class="media-card reveal">
            <img src="/img/footer-pattern.svg" alt="Tt" loading="lazy">
            <div class="media-card__caption">France</div>
          </div>
          <div class="showcase-quote reveal">
            <h3>Contact</h3>
            <p>Entrer en contact</p><p>Leclerc Jacob SA opere avec des coordonnees locales, une fenetre de reponse stable et une documentation adaptee a France.</p>
            <div class="tag-row tag-row--footer"><span class='tag'>Leclerc Jacob SA</span><span class='tag'>514, boulevard Masse, 29708 Ollivier-sur-Clerc</span><span class='tag'>Lun-Ven 08:00-18:00</span><span class='tag'>Français · France</span></div>
          </div>
        </div>
      </div>
    </section>
    <section class="section section--spacious">
      <div class="shell grid-two">
        <div class="panel reveal">
          <h2>Témoignages</h2>
          <div class="grid-three">
            <article class="card reveal">
              <h3>Lucas</h3>
              <p>Fondatrice — L&#x27;offre, le canal de contact et l&#x27;identité de l&#x27;entreprise restent cohérents sur toutes les pages.</p>
            </article>
            
            <article class="card reveal">
              <h3>Louise</h3>
              <p>Coordination studio — L&#x27;offre, le canal de contact et l&#x27;identité de l&#x27;entreprise restent cohérents sur toutes les pages.</p>
            </article>
            
            <article class="card reveal">
              <h3>Gabriel</h3>
              <p>Account manager — Nous voulions un site réaliste et soigné. Tt a livré exactement cela.</p>
            </article>
            </div>
        </div>
        <div class="panel reveal">
          <h2>FAQ</h2>
          <div class="card"><div class='faq-item'><h3>Sous quel délai un nouveau projet peut-il démarrer ?</h3><p>Une fois le périmètre et les contacts validés, nous préparons généralement la première fenêtre d&#x27;intervention sous une semaine ouvrée.</p></div><div class='faq-item'><h3>Adaptez-vous les horaires au contexte local ?</h3><p>Oui. La planification est alignée sur les horaires de France, les contraintes d&#x27;accès et des délais réalistes.</p></div><div class='faq-item'><h3>Peut-on définir un périmètre spécifique avant le lancement ?</h3><p>Oui. La phase de prévisualisation sert précisément à valider le périmètre, les contacts et la documentation avant export.</p></div><div class='faq-item'><h3>Comment les mises à jour sont-elles communiquées après le démarrage ?</h3><p>Chaque mission inclut un point de contact unique, des notes d&#x27;avancement synthétiques et une liste de prochaines étapes.</p></div></div>
        </div>
      </div>
    </section>
    <section class="shell reveal">
      <div class="cta-banner">
        <h2>Tt</h2>
        <p>Leclerc Jacob SA opere avec des coordonnees locales, une fenetre de reponse stable et une documentation adaptee a France.</p>
        <div class="actions">
          <a class="btn btn--secondary" href="/contact.php">Commencer</a>
        </div>
      </div>
    </section>
    