<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Contact - tt",
  "meta_description": "Entrer en contact"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/contact.php';
require __DIR__ . '/includes/layout.php';