<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "tt",
  "meta_description": "France with consistent brandin g , reachable contact cla ir et des informations d'entreprise cohérentes . France with realistic local contact data and clear nex"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/index.php';
require __DIR__ . '/includes/layout.php';