<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "À propos - tt",
  "meta_description": "Sensibilité à Marketing Agency passent par info@tt .com et des plages d'intervention réalistes. Built for France with consistent brandi n g, reachable contact d"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/about.php';
require __DIR__ . '/includes/layout.php';