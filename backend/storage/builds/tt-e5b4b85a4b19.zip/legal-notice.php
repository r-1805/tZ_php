<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Mentions légales - tt",
  "meta_description": "Commission Nationale de l'Informatique et des Libertés"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/legal-notice.php';
require __DIR__ . '/includes/layout.php';