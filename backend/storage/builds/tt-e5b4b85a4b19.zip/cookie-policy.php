<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Politique de cookies - tt",
  "meta_description": "France"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/cookie-policy.php';
require __DIR__ . '/includes/layout.php';