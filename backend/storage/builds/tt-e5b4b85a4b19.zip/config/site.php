<?php
return json_decode(<<<'JSON'
{
  "html_lang": "fr",
  "brand": "tt",
  "brand_initials": "T",
  "footer_blurb": "Microsite public genere pour une presence locale credible, un parcours de contact clair et une base legale adaptee au marche.",
  "year": 2026,
  "company": {
    "brand": "tt",
    "brand_display": "Tt",
    "domain": "tt.com",
    "legal_entity_name": "Leclerc Jacob SA",
    "email": "info@tt.com",
    "phone": "+33 01 198 2560",
    "address": "514, boulevard Masse, 29708 Ollivier-sur-Clerc",
    "hours": "Lun-Ven 08:00-18:00",
    "social_handles": {
      "facebook": "tt_facebook",
      "twitter": "tt_twitter",
      "instagram": "tt_instagram"
    }
  },
  "tel_href": "+33011982560",
  "contact_heading": "Contact",
  "legal_heading": "Conformite",
  "cookie_title": "Politique de cookies",
  "cookie_text": "Nous utilisons des cookies essentiels et du stockage local pour garder la navigation stable, memoriser vos choix et proteger les fonctions de base.",
  "cookie_accept": "Accepter",
  "cookie_link": "Lire la politique cookies",
  "extra_head_html": "<meta name=\"generator\" content=\"Drupal 9 (https://www.drupal.org)\" />",
  "nav": [
    {
      "file": "index.php",
      "label": "Accueil"
    },
    {
      "file": "about.php",
      "label": "À propos"
    },
    {
      "file": "offerings.php",
      "label": "Offres"
    },
    {
      "file": "portfolio.php",
      "label": "Portefeuille"
    },
    {
      "file": "contact.php",
      "label": "Contact"
    },
    {
      "file": "news-archive.php",
      "label": "Archives"
    }
  ],
  "legal_links": [
    {
      "file": "privacy-policy.php",
      "label": "Politique de confidentialité"
    },
    {
      "file": "cookie-policy.php",
      "label": "Politique de cookies"
    },
    {
      "file": "terms-of-service.php",
      "label": "Conditions d'utilisation"
    },
    {
      "file": "legal-notice.php",
      "label": "Mentions légales"
    },
    {
      "file": "disclaimer.php",
      "label": "Avis de non-responsabilité"
    }
  ]
}
JSON, true);
