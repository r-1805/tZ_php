<?php
return json_decode(<<<'JSON'
{
  "html_lang": "en",
  "brand": "northpeakstudio",
  "brand_initials": "N",
  "footer_blurb": "Public-facing microsite generated for realistic local business discovery, contact routing, and compliant legal disclosure.",
  "year": 2026,
  "company": {
    "brand": "northpeakstudio",
    "brand_display": "Northpeakstudio",
    "domain": "northpeakstudio.com",
    "legal_entity_name": "Northpeakstudio LLC",
    "email": "contact@northpeakstudio.com",
    "phone": "+1 (510) 364-2696",
    "address": "12 Hollywood Blvd, Los Angeles, CA 90210",
    "hours": "Tue-Sun 10:00-20:00",
    "social_handles": {
      "facebook": "northpeakstudio_facebook",
      "twitter": "northpeakstudio_twitter",
      "instagram": "northpeakstudio_instagram"
    }
  },
  "tel_href": "+15103642696",
  "contact_heading": "Contact",
  "legal_heading": "Compliance",
  "cookie_title": "Cookie Policy",
  "cookie_text": "We use essential cookies and local storage to keep navigation stable, remember your preference, and protect basic form flows.",
  "cookie_accept": "Accept",
  "cookie_link": "Read cookie policy",
  "nav": [
    {
      "file": "index.php",
      "label": "Home"
    },
    {
      "file": "about.php",
      "label": "About"
    },
    {
      "file": "offerings.php",
      "label": "Offerings"
    },
    {
      "file": "portfolio.php",
      "label": "Portfolio"
    },
    {
      "file": "contact.php",
      "label": "Contact"
    }
  ],
  "legal_links": [
    {
      "file": "privacy-policy.php",
      "label": "Privacy Policy"
    },
    {
      "file": "cookie-policy.php",
      "label": "Cookie Policy"
    },
    {
      "file": "terms-of-service.php",
      "label": "Terms of Service"
    },
    {
      "file": "legal-notice.php",
      "label": "Legal Notice"
    },
    {
      "file": "disclaimer.php",
      "label": "Disclaimer"
    }
  ]
}
JSON, true);
