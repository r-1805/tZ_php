<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Portfolio - northpeakstudio",
  "meta_description": "Brand Launch, E-commerce Campaign, SEO Optimization"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/portfolio.php';
require __DIR__ . '/includes/layout.php';