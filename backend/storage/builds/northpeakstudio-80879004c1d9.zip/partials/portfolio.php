
    <section class="legal-page">
      <div class="shell stack">
        <h1>Portfolio</h1>
        <p class="lead">Northpeakstudio presents a structured set of categories so visitors can review the offer without needing external context.</p>
        <div class="grid-three">
            <article class="card">
              <h3>Brand Launch</h3>
              <p>Brand Launch is delivered with defined milestones, market-aware wording, and realistic local coordination for United States.</p>
            </article>
            
            <article class="card">
              <h3>E-commerce Campaign</h3>
              <p>E-commerce Campaign is delivered with defined milestones, market-aware wording, and realistic local coordination for United States.</p>
            </article>
            
            <article class="card">
              <h3>SEO Optimization</h3>
              <p>SEO Optimization is delivered with defined milestones, market-aware wording, and realistic local coordination for United States.</p>
            </article>
            </div>
      </div>
    </section>
    