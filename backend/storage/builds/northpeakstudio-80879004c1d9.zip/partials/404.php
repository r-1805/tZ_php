
    <section class="error-page">
      <div class="shell stack">
        <span class="kicker">404</span>
        <h1>Page not found</h1>
        <p class="lead">We use essential cookies and local storage to keep navigation stable, remember your preference, and protect basic form flows.</p>
        <div class="actions">
          <a class="btn btn--primary" href="/index.php">Back to home</a>
        </div>
      </div>
    </section>
    