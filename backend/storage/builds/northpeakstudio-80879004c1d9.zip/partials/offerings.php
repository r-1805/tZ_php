
    <section class="legal-page">
      <div class="shell stack">
        <h1>Offerings</h1>
        <p class="lead">Northpeakstudio presents a structured set of categories so visitors can review the offer without needing external context.</p>
        <div class="grid-three">
            <article class="card">
              <h3>SEO Services</h3>
              <p>SEO Services is delivered with defined milestones, market-aware wording, and realistic local coordination for United States.</p>
            </article>
            
            <article class="card">
              <h3>Social Media Marketing</h3>
              <p>Social Media Marketing is delivered with defined milestones, market-aware wording, and realistic local coordination for United States.</p>
            </article>
            
            <article class="card">
              <h3>Digital Marketing</h3>
              <p>Digital Marketing is delivered with defined milestones, market-aware wording, and realistic local coordination for United States.</p>
            </article>
            </div>
      </div>
    </section>
    