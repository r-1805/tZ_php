
    <section class="legal-page">
      <div class="shell stack">
        <h1>Contact</h1>
        <p class="lead">Get in Touch</p>
        <div class="grid-three">
          <article class="card">
            <h3>Northpeakstudio LLC</h3>
            <p>12 Hollywood Blvd, Los Angeles, CA 90210</p>
            <p><a href="mailto:contact@northpeakstudio.com">contact@northpeakstudio.com</a></p>
            <p><a href="tel:+1(510)364-2696">+1 (510) 364-2696</a></p>
            <p>Tue-Sun 10:00-20:00</p>
          </article>
          <article class="card">
            <h3>Webadresse</h3>
            <img src="/img/contact-pattern.svg" alt="Northpeakstudio" loading="lazy">
            <p>northpeakstudio.com</p>
            <h3>Market</h3>
            <p>United States</p>
            <h3>Language</h3>
            <p>English</p>
          </article>
          <article class="card">
            <h3>Social profiles</h3>
            <ul class="contact-list"><li>Facebook: @northpeakstudio_facebook</li><li>Twitter: @northpeakstudio_twitter</li><li>Instagram: @northpeakstudio_instagram</li></ul>
          </article>
        </div>
      </div>
    </section>
    