
    <section class="hero">
      <div class="shell hero__grid">
        <div class="hero__main">
          <span class="kicker">Northpeakstudio</span>
          <h1>Northpeakstudio for United States</h1>
          <p class="lead">Built for United States with consistent branding, reachable contact routes, and market-aware legal pages.</p>
          <div class="actions">
            <a class="btn btn--primary" href="/contact.php">Get Started</a>
            <a class="btn btn--secondary" href="#services">Learn More</a>
          </div>
          <div class="tag-row"><span class='tag'><strong>28h</strong> Tue-Sun 10:00-20:00</span><span class='tag'><strong>10</strong> Startups</span><span class='tag'><strong>96%</strong> Overview</span></div>
        </div>
        <aside class="panel hero__visual">
          <div class="hero__visual-card">
            <img src="/img/hero-pattern.svg" alt="Northpeakstudio" loading="lazy">
          </div>
          <h3>Contact</h3>
          <dl>
            <div><dt>Webadresse</dt><dd>northpeakstudio.com</dd></div>
            <div><dt>Email</dt><dd>contact@northpeakstudio.com</dd></div>
            <div><dt>Phone</dt><dd>+1 (510) 364-2696</dd></div>
            <div><dt>Address</dt><dd>12 Hollywood Blvd, Los Angeles, CA 90210</dd></div>
            <div><dt>Language</dt><dd>English</dd></div>
          </dl>
        </aside>
      </div>
    </section>
    <section class="section" id="services">
      <div class="shell">
        <div class="section__header">
          <h2>Why Choose Us</h2>
          <p class="lead">Every page keeps the business identity, service scope, and compliance signals consistent for visitors in United States.</p>
        </div>
        <div class="grid-three">
            <article class="card">
              <h3>SEO Services</h3>
              <p>Increased Brand Awareness</p>
            </article>
            
            <article class="card">
              <h3>Social Media Marketing</h3>
              <p>Higher Website Traffic</p>
            </article>
            
            <article class="card">
              <h3>Digital Marketing</h3>
              <p>Improved ROI</p>
            </article>
            </div>
      </div>
    </section>
    <section class="section">
      <div class="shell copy">
        <div class="stack">
          <h2>Overview</h2>
          <p>Every page keeps the business identity, service scope, and compliance signals consistent for visitors in United States.</p><p>Northpeakstudio serves Startups across United States with an emphasis on realistic local operations and concise handoff notes.</p>
        </div>
        <div class="stack">
          <h2>Contact</h2>
          <p>Get in Touch</p><p>Northpeakstudio LLC operates with local contact data, a consistent response window, and market-aware documentation for United States.</p>
          <div class="tag-row tag-row--footer"><span class='tag'>Northpeakstudio LLC</span><span class='tag'>12 Hollywood Blvd, Los Angeles, CA 90210</span><span class='tag'>Tue-Sun 10:00-20:00</span><span class='tag'>English · United States</span></div>
        </div>
      </div>
    </section>
    <section class="section">
      <div class="shell">
        <div class="section__header">
          <h2>Testimonials</h2>
        </div>
        <div class="grid-three">
            <article class="card">
              <h3>Morgan</h3>
              <p>Operations lead — We wanted something realistic and polished. Northpeakstudio delivered exactly that.</p>
            </article>
            
            <article class="card">
              <h3>Avery</h3>
              <p>Operations lead — The site makes the offer, contact path, and business identity feel consistent across every page.</p>
            </article>
            
            <article class="card">
              <h3>Morgan</h3>
              <p>Account manager — The site makes the offer, contact path, and business identity feel consistent across every page.</p>
            </article>
            </div>
      </div>
    </section>
    <section class="section">
      <div class="shell">
        <div class="section__header">
          <h2>FAQ</h2>
        </div>
        <div class="card"><div class='faq-item'><h3>How quickly can a new engagement start?</h3><p>We usually prepare the initial operating window within one working week once the scope and contacts are confirmed.</p></div><div class='faq-item'><h3>Do you adapt service windows to local schedules?</h3><p>Yes. Scheduling is planned around United States business hours, access constraints, and realistic response windows.</p></div><div class='faq-item'><h3>Can we request a custom scope before launch?</h3><p>Yes. The preview stage is designed to confirm scope, contact details, and documentation before export.</p></div><div class='faq-item'><h3>How are updates communicated after kickoff?</h3><p>Every engagement includes a single contact route, concise status notes, and a documented next-step list.</p></div></div>
      </div>
    </section>
    <section class="shell">
      <div class="cta-banner">
        <h2>Northpeakstudio</h2>
        <p>Northpeakstudio LLC operates with local contact data, a consistent response window, and market-aware documentation for United States.</p>
        <div class="actions">
          <a class="btn btn--secondary" href="/contact.php">Get Started</a>
        </div>
      </div>
    </section>
    