<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "kaffee-berlin",
  "meta_description": "Built for Deutschland with consistent branding, reachable contact routes, and market-aware legal pages."
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/index.php';
require __DIR__ . '/includes/layout.php';