<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Über uns - kaffee-berlin",
  "meta_description": "Every page keeps the business identity, service scope, and compliance signals consistent for visitors in Deutschland."
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/about.php';
require __DIR__ . '/includes/layout.php';