<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Portfolio - kaffee-berlin",
  "meta_description": "Private Party, Wochenend-Brunch, Firmenevent"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/portfolio.php';
require __DIR__ . '/includes/layout.php';