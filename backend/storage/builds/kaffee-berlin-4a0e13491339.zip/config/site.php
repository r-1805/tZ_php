<?php
return json_decode(<<<'JSON'
{
  "html_lang": "de",
  "brand": "kaffee-berlin",
  "brand_initials": "KB",
  "footer_blurb": "Offentliche Microsite fur lokale Anfragen, nachvollziehbare Kontaktwege und rechtskonforme Hinweise im gewahlten Markt.",
  "year": 2026,
  "company": {
    "brand": "kaffee-berlin",
    "brand_display": "Kaffee Berlin",
    "domain": "kaffee-berlin.de",
    "legal_entity_name": "Kaffee Berlin GmbH",
    "email": "contact@kaffee-berlin.de",
    "phone": "+49 0221 9068060",
    "address": "85 Mönckebergstraße, Hamburg, Hamburg 10117",
    "hours": "Mo-Sa 09:00-19:00",
    "social_handles": {
      "facebook": "kaffeeberlin_facebook",
      "twitter": "kaffeeberlin_twitter",
      "instagram": "kaffeeberlin_instagram"
    }
  },
  "tel_href": "+4902219068060",
  "contact_heading": "Kontakt",
  "legal_heading": "Rechtliches",
  "cookie_title": "Cookie-Richtlinie",
  "cookie_text": "Wir nutzen notwendige Cookies und lokalen Speicher, um die Navigation stabil zu halten, Einstellungen zu speichern und Basisfunktionen zu schutzen.",
  "cookie_accept": "Akzeptieren",
  "cookie_link": "Cookie-Richtlinie lesen",
  "nav": [
    {
      "file": "index.php",
      "label": "Startseite"
    },
    {
      "file": "about.php",
      "label": "Über uns"
    },
    {
      "file": "offerings.php",
      "label": "Angebote"
    },
    {
      "file": "portfolio.php",
      "label": "Portfolio"
    },
    {
      "file": "contact.php",
      "label": "Kontakt"
    }
  ],
  "legal_links": [
    {
      "file": "privacy-policy.php",
      "label": "Datenschutzrichtlinie"
    },
    {
      "file": "cookie-policy.php",
      "label": "Cookie-Richtlinie"
    },
    {
      "file": "terms-of-service.php",
      "label": "Nutzungsbedingungen"
    },
    {
      "file": "legal-notice.php",
      "label": "Impressum"
    },
    {
      "file": "disclaimer.php",
      "label": "Haftungsausschluss"
    }
  ]
}
JSON, true);
