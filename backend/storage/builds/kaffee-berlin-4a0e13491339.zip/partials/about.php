
    <section class="legal-page">
      <div class="shell stack">
        <h1>Kaffee Berlin</h1>
        <div class="copy">
          <div class="stack"><p>Every page keeps the business identity, service scope, and compliance signals consistent for visitors in Deutschland.</p><p>Kaffee Berlin arbeitet mit einem dokumentierten Betriebsmodell, realistischen lokalen Kontaktdaten und klaren Reaktionsfenstern.</p></div>
          <div class="stack">
            <p>Die Seitenstruktur ist auf Deutschland abgestimmt, damit Angebot, Unternehmensidentitat und Kontaktweg sofort nachvollziehbar sind.</p><p>Kaffee Berlin GmbH - 85 Mönckebergstraße, Hamburg, Hamburg 10117</p>
            <img src="/img/footer-pattern.svg" alt="Kaffee Berlin" loading="lazy">
            <ul class="contact-list"><li>Facebook: @kaffeeberlin_facebook</li><li>Twitter: @kaffeeberlin_twitter</li><li>Instagram: @kaffeeberlin_instagram</li></ul>
          </div>
        </div>
      </div>
    </section>
    