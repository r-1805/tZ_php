
    <section class="legal-page">
      <div class="shell stack">
        <h1>Portfolio</h1>
        <p class="lead">Kaffee Berlin prasentiert ein strukturiertes Leistungsbild, damit Besucher das Angebot ohne Zusatzkontext verstehen konnen.</p>
        <div class="grid-three">
            <article class="card">
              <h3>Private Party</h3>
              <p>Private Party wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            
            <article class="card">
              <h3>Wochenend-Brunch</h3>
              <p>Wochenend-Brunch wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            
            <article class="card">
              <h3>Firmenevent</h3>
              <p>Firmenevent wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            </div>
      </div>
    </section>
    