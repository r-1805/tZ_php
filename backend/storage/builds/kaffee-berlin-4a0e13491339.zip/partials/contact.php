
    <section class="legal-page">
      <div class="shell stack">
        <h1>Kontakt</h1>
        <p class="lead">Kontakt aufnehmen</p>
        <div class="grid-three">
          <article class="card">
            <h3>Kaffee Berlin GmbH</h3>
            <p>85 Mönckebergstraße, Hamburg, Hamburg 10117</p>
            <p><a href="mailto:contact@kaffee-berlin.de">contact@kaffee-berlin.de</a></p>
            <p><a href="tel:+4902219068060">+49 0221 9068060</a></p>
            <p>Mo-Sa 09:00-19:00</p>
          </article>
          <article class="card">
            <h3>Webadresse</h3>
            <img src="/img/contact-pattern.svg" alt="Kaffee Berlin" loading="lazy">
            <p>kaffee-berlin.de</p>
            <h3>Markt</h3>
            <p>Deutschland</p>
            <h3>Sprache</h3>
            <p>Deutsch</p>
          </article>
          <article class="card">
            <h3>Soziale Profile</h3>
            <ul class="contact-list"><li>Facebook: @kaffeeberlin_facebook</li><li>Twitter: @kaffeeberlin_twitter</li><li>Instagram: @kaffeeberlin_instagram</li></ul>
          </article>
        </div>
      </div>
    </section>
    