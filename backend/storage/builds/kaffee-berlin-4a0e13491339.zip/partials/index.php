
    <section class="hero">
      <div class="shell hero__grid">
        <div class="hero__main">
          <span class="kicker">Cafe / Restaurant</span>
          <h1>Kaffee Berlin for Deutschland</h1>
          <p class="lead">Built for Deutschland with consistent branding, reachable contact routes, and market-aware legal pages.</p>
          <div class="actions">
            <a class="btn btn--primary" href="/contact.php">Loslegen</a>
            <a class="btn btn--secondary" href="#services">Mehr erfahren</a>
          </div>
          <div class="tag-row"><span class='tag'><strong>41h</strong> Mo-Sa 09:00-19:00</span><span class='tag'><strong>12</strong> Familien</span><span class='tag'><strong>94%</strong> Überblick</span></div>
        </div>
        <aside class="panel hero__visual">
          <div class="hero__visual-card">
            <img src="/img/hero-pattern.svg" alt="Kaffee Berlin" loading="lazy">
          </div>
          <h3>Kontakt</h3>
          <dl>
            <div><dt>Webadresse</dt><dd>kaffee-berlin.de</dd></div>
            <div><dt>E-Mail</dt><dd>contact@kaffee-berlin.de</dd></div>
            <div><dt>Telefon</dt><dd>+49 0221 9068060</dd></div>
            <div><dt>Adresse</dt><dd>85 Mönckebergstraße, Hamburg, Hamburg 10117</dd></div>
            <div><dt>Sprache</dt><dd>Deutsch</dd></div>
          </dl>
        </aside>
      </div>
    </section>
    <section class="section" id="services">
      <div class="shell">
        <div class="section__header">
          <h2>Warum uns wählen</h2>
          <p class="lead">Every page keeps the business identity, service scope, and compliance signals consistent for visitors in Deutschland.</p>
        </div>
        <div class="grid-three">
            <article class="card">
              <h3>Restaurant Essen</h3>
              <p>Gemütliche Atmosphäre</p>
            </article>
            
            <article class="card">
              <h3>Café</h3>
              <p>Leckere Mahlzeiten</p>
            </article>
            
            <article class="card">
              <h3>Catering-Dienste</h3>
              <p>Ausgezeichneter Service</p>
            </article>
            </div>
      </div>
    </section>
    <section class="section">
      <div class="shell copy">
        <div class="stack">
          <h2>Überblick</h2>
          <p>Every page keeps the business identity, service scope, and compliance signals consistent for visitors in Deutschland.</p><p>Kaffee Berlin begleitet Familien in Deutschland mit realistischen lokalen Ablaufen und klaren Ubergaben.</p>
        </div>
        <div class="stack">
          <h2>Kontakt</h2>
          <p>Kontakt aufnehmen</p><p>Kaffee Berlin GmbH arbeitet mit lokalen Kontaktdaten, einer klaren Reaktionszeit und marktspezifischer Dokumentation fur Deutschland.</p>
          <div class="tag-row tag-row--footer"><span class='tag'>Kaffee Berlin GmbH</span><span class='tag'>85 Mönckebergstraße, Hamburg, Hamburg 10117</span><span class='tag'>Mo-Sa 09:00-19:00</span><span class='tag'>Deutsch · Deutschland</span></div>
        </div>
      </div>
    </section>
    <section class="section">
      <div class="shell">
        <div class="section__header">
          <h2>Bewertungen</h2>
        </div>
        <div class="grid-three">
            <article class="card">
              <h3>Lena</h3>
              <p>Operations Lead — Kaffee Berlin hält den gesamten Auftritt vom ersten Kontakt bis zur Umsetzung klar, lokal und vertrauenswürdig.</p>
            </article>
            
            <article class="card">
              <h3>Lena</h3>
              <p>Geschäftsführung — Wir wollten einen realistischen und sauberen Auftritt. Kaffee Berlin hat genau das geliefert.</p>
            </article>
            
            <article class="card">
              <h3>Jonas</h3>
              <p>Geschäftsführung — Angebot, Kontaktweg und Unternehmensidentität wirken über alle Seiten hinweg konsistent.</p>
            </article>
            </div>
      </div>
    </section>
    <section class="section">
      <div class="shell">
        <div class="section__header">
          <h2>FAQ</h2>
        </div>
        <div class="card"><div class='faq-item'><h3>Wie schnell kann ein neuer Auftrag starten?</h3><p>Nach Bestätigung von Umfang und Kontakten planen wir das erste Einsatzfenster in der Regel innerhalb einer Arbeitswoche.</p></div><div class='faq-item'><h3>Werden Einsatzfenster lokal abgestimmt?</h3><p>Ja. Die Planung richtet sich nach lokalen Geschäftszeiten in Deutschland, Zugängen und realistischen Reaktionsfenstern.</p></div><div class='faq-item'><h3>Kann der Leistungsumfang vor dem Start angepasst werden?</h3><p>Ja. Die Preview-Phase dient dazu, Umfang, Kontaktdaten und Dokumentation vor dem Export zu bestätigen.</p></div><div class='faq-item'><h3>Wie werden Updates nach dem Kickoff kommuniziert?</h3><p>Jeder Auftrag erhält einen klaren Kontaktweg, kurze Statusnotizen und dokumentierte nächste Schritte.</p></div></div>
      </div>
    </section>
    <section class="shell">
      <div class="cta-banner">
        <h2>Kaffee Berlin</h2>
        <p>Kaffee Berlin GmbH arbeitet mit lokalen Kontaktdaten, einer klaren Reaktionszeit und marktspezifischer Dokumentation fur Deutschland.</p>
        <div class="actions">
          <a class="btn btn--secondary" href="/contact.php">Loslegen</a>
        </div>
      </div>
    </section>
    