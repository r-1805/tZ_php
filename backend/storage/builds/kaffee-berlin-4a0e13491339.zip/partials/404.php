
    <section class="error-page">
      <div class="shell stack">
        <span class="kicker">404</span>
        <h1>Seite nicht gefunden</h1>
        <p class="lead">Wir nutzen notwendige Cookies und lokalen Speicher, um die Navigation stabil zu halten, Einstellungen zu speichern und Basisfunktionen zu schutzen.</p>
        <div class="actions">
          <a class="btn btn--primary" href="/index.php">Zur Startseite</a>
        </div>
      </div>
    </section>
    