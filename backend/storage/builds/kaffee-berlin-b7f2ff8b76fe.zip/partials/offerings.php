
    <section class="legal-page">
      <div class="shell stack">
        <h1>Angebote</h1>
        <p class="lead">Kaffee Berlin prasentiert ein strukturiertes Leistungsbild, damit Besucher das Angebot ohne Zusatzkontext verstehen konnen.</p>
        <div class="grid-three">
            <article class="card">
              <h3>Catering-Dienste</h3>
              <p>Catering-Dienste wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            
            <article class="card">
              <h3>Restaurant Essen</h3>
              <p>Restaurant Essen wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            
            <article class="card">
              <h3>Café</h3>
              <p>Café wird mit definierten Meilensteinen, marktgerechter Sprache und realistischer lokaler Koordination fur Deutschland dargestellt.</p>
            </article>
            </div>
      </div>
    </section>
    