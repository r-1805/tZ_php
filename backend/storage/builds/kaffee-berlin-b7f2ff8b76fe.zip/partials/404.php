
    <section class="error-page">
      <div class="shell stack">
        <span class="kicker">404</span>
        <h1>Seite nicht gefunden</h1>
        <p class="lead">Die Seite wurde nicht gefunden. Möglicherweise wurde sie verschoben oder die Adresse hat sich geändert.</p>
        <div class="actions">
          <a class="btn btn--primary" href="/index.php">Zur Startseite</a>
        </div>
      </div>
    </section>
    