
    <section class="legal-page">
      <div class="shell stack">
        <h1>Kontakt</h1>
        <p class="lead">Kontakt aufnehmen</p>
        <div class="grid-three">
          <article class="card">
            <h3>Weinhold</h3>
            <p>Josef-Kusch-Ring 39, 89436 Starnberg</p>
            <p><a href="mailto:info@kaffee-berlin.de">info@kaffee-berlin.de</a></p>
            <p><a href="tel:+49(0)643686352">+49(0)6436 86352</a></p>
            <p>Mo-Sa 09:00-19:00</p>
          </article>
          <article class="card">
            <h3>Webadresse</h3>
            <img src="/img/contact-pattern.svg" alt="Kaffee Berlin" loading="lazy">
            <p>kaffee-berlin.de</p>
            <h3>Markt</h3>
            <p>Deutschland</p>
            <h3>Sprache</h3>
            <p>Deutsch</p>
          </article>
          <article class="card">
            <h3>Soziale Profile</h3>
            <ul class="contact-list"><li>Facebook: @kaffeeberlin_facebook</li><li>Twitter: @kaffeeberlin_twitter</li><li>Instagram: @kaffeeberlin_instagram</li></ul>
          </article>
        </div>
      </div>
    </section>
    