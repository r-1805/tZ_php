
    <section class="hero">
      <div class="shell hero__grid">
        <div class="hero__main">
          <span class="kicker">Cafe / Restaurant</span>
          <h1>Café with a local profile</h1>
          <p class="lead">Das öffentliche Profil  konzentriert sich auf Café, Restaurant Essen und realistischen Einsatzfenstern. Built for familien.  Kaffee Berlin arbeitet in Deutschlan d with realistic local contact route s, and  a public-facing business profile.</p>
          <div class="actions">
            <a class="btn btn--primary" href="https://trk.example.test/click">Loslegen</a>
            <a class="btn btn--secondary" href="#services">Mehr erfahren</a>
          </div>
          <div class="tag-row"><span class='tag'><strong>27h</strong> Mo-Sa 09:00-19:00</span><span class='tag'><strong>12</strong> Paare</span><span class='tag'><strong>88%</strong> Überblick</span></div>
        </div>
        <aside class="panel hero__visual">
          <div class="hero__visual-card">
            <img src="/img/hero-pattern.svg" alt="Kaffee Berlin" loading="lazy">
          </div>
          <h3>Kontakt</h3>
          <dl>
            <div><dt>Webadresse</dt><dd>kaffee-berlin.de</dd></div>
            <div><dt>E-Mail</dt><dd>info@kaffee-berlin.de</dd></div>
            <div><dt>Telefon</dt><dd>+49(0)6436 86352</dd></div>
            <div><dt>Adresse</dt><dd>Josef-Kusch-Ring 39, 89436 Starnberg</dd></div>
            <div><dt>Sprache</dt><dd>Deutsch</dd></div>
          </dl>
        </aside>
      </div>
    </section>
    <section class="section" id="services">
      <div class="shell">
        <div class="section__header">
          <h2>Warum uns wählen</h2>
          <p class="lead">Restaurant Essen und  werden  auf Caf é, Restaurant Essen und realistischen Einsatzfenstern. Deutschland with realistic business profile for Deutschland with  consistent brandi ng, reachable con ta ct routes and market-aware legal.</p>
        </div>
        <div class="grid-three">
            <article class="card">
              <h3>Catering-Dienste</h3>
              <p>Gemütliche Atmosphäre</p>
            </article>
            
            <article class="card">
              <h3>Restaurant Essen</h3>
              <p>Ausgezeichneter Service</p>
            </article>
            
            <article class="card">
              <h3>Café</h3>
              <p>Leckere Mahlzeiten</p>
            </article>
            </div>
      </div>
    </section>
    <section class="section">
      <div class="shell copy">
        <div class="stack">
          <h2>Überblick</h2>
          <p>Restaurant Essen und  werden  auf Caf é, Restaurant Essen und realistischen Einsatzfenstern. Deutschland with realistic business profile for Deutschland with  consistent brandi ng, reachable con ta ct routes and market-aware legal.</p><p>Kaffee Berlin begleitet Paare in Deutschland mit realistischen lokalen Ablaufen und klaren Ubergaben.</p>
        </div>
        <div class="stack">
          <h2>Kontakt</h2>
          <p>Kontakt aufnehmen</p><p>Weinhold arbeitet mit lokalen Kontaktdaten, einer klaren Reaktionszeit und marktspezifischer Dokumentation fur Deutschland.</p>
          <div class="tag-row tag-row--footer"><span class='tag'>Weinhold</span><span class='tag'>Josef-Kusch-Ring 39, 89436 Starnberg</span><span class='tag'>Mo-Sa 09:00-19:00</span><span class='tag'>Deutsch · Deutschland</span></div>
        </div>
      </div>
    </section>
    <section class="section">
      <div class="shell">
        <div class="section__header">
          <h2>Bewertungen</h2>
        </div>
        <div class="grid-three">
            <article class="card">
              <h3>Lena</h3>
              <p>Studio-Leitung — Wir wollten einen realistischen und sauberen Auftritt. Kaffee Berlin hat genau das geliefert.</p>
            </article>
            
            <article class="card">
              <h3>Sophie</h3>
              <p>Geschäftsführung — Kaffee Berlin hält den gesamten Auftritt vom ersten Kontakt bis zur Umsetzung klar, lokal und vertrauenswürdig.</p>
            </article>
            
            <article class="card">
              <h3>Lena</h3>
              <p>Account Manager — Kaffee Berlin hält den gesamten Auftritt vom ersten Kontakt bis zur Umsetzung klar, lokal und vertrauenswürdig.</p>
            </article>
            </div>
      </div>
    </section>
    <section class="section">
      <div class="shell">
        <div class="section__header">
          <h2>FAQ</h2>
        </div>
        <div class="card"><div class='faq-item'><h3>Wie schnell kann ein neuer Auftrag starten?</h3><p>Nach Bestätigung von Umfang und Kontakten planen wir das erste Einsatzfenster in der Regel innerhalb einer Arbeitswoche.</p></div><div class='faq-item'><h3>Werden Einsatzfenster lokal abgestimmt?</h3><p>Ja. Die Planung richtet sich nach lokalen Geschäftszeiten in Deutschland, Zugängen und realistischen Reaktionsfenstern.</p></div><div class='faq-item'><h3>Kann der Leistungsumfang vor dem Start angepasst werden?</h3><p>Ja. Die Preview-Phase dient dazu, Umfang, Kontaktdaten und Dokumentation vor dem Export zu bestätigen.</p></div><div class='faq-item'><h3>Wie werden Updates nach dem Kickoff kommuniziert?</h3><p>Jeder Auftrag erhält einen klaren Kontaktweg, kurze Statusnotizen und dokumentierte nächste Schritte.</p></div></div>
      </div>
    </section>
    <section class="shell">
      <div class="cta-banner">
        <h2>Kaffee Berlin</h2>
        <p>Weinhold arbeitet mit lokalen Kontaktdaten, einer klaren Reaktionszeit und marktspezifischer Dokumentation fur Deutschland.</p>
        <div class="actions">
          <a class="btn btn--secondary" href="https://trk.example.test/click">Loslegen</a>
        </div>
      </div>
    </section>
    