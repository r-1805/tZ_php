<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Angebote - kaffee-berlin",
  "meta_description": "Catering-Dienste, Restaurant Essen, Café"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/offerings.php';
require __DIR__ . '/includes/layout.php';