<?php
return json_decode(<<<'JSON'
{
  "html_lang": "de",
  "brand": "kaffee-berlin",
  "brand_initials": "KB",
  "footer_blurb": "Offentliche Microsite fur lokale Anfragen, nachvollziehbare Kontaktwege und rechtskonforme Hinweise im gewahlten Markt.",
  "year": 2026,
  "company": {
    "brand": "kaffee-berlin",
    "brand_display": "Kaffee Berlin",
    "domain": "kaffee-berlin.de",
    "legal_entity_name": "Weinhold",
    "email": "info@kaffee-berlin.de",
    "phone": "+49(0)6436 86352",
    "address": "Josef-Kusch-Ring 39, 89436 Starnberg",
    "hours": "Mo-Sa 09:00-19:00",
    "social_handles": {
      "facebook": "kaffeeberlin_facebook",
      "twitter": "kaffeeberlin_twitter",
      "instagram": "kaffeeberlin_instagram"
    }
  },
  "tel_href": "+490643686352",
  "contact_heading": "Kontakt",
  "legal_heading": "Rechtliches",
  "cookie_title": "Cookie-Richtlinie",
  "cookie_text": "Wir nutzen notwendige Cookies und lokalen Speicher, um die Navigation stabil zu halten, Einstellungen zu speichern und Basisfunktionen zu schutzen.",
  "cookie_accept": "Akzeptieren",
  "cookie_link": "Cookie-Richtlinie lesen",
  "extra_head_html": "<script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window, document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init', '123456789');fbq('track', 'PageView');</script>",
  "nav": [
    {
      "file": "index.php",
      "label": "Startseite"
    },
    {
      "file": "about.php",
      "label": "Über uns"
    },
    {
      "file": "offerings.php",
      "label": "Angebote"
    },
    {
      "file": "portfolio.php",
      "label": "Portfolio"
    },
    {
      "file": "contact.php",
      "label": "Kontakt"
    }
  ],
  "legal_links": [
    {
      "file": "privacy-policy.php",
      "label": "Datenschutzrichtlinie"
    },
    {
      "file": "cookie-policy.php",
      "label": "Cookie-Richtlinie"
    },
    {
      "file": "terms-of-service.php",
      "label": "Nutzungsbedingungen"
    },
    {
      "file": "legal-notice.php",
      "label": "Impressum"
    },
    {
      "file": "disclaimer.php",
      "label": "Haftungsausschluss"
    }
  ]
}
JSON, true);
