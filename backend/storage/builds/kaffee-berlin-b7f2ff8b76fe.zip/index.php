<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "kaffee-berlin",
  "meta_description": "Das öffentliche Profil konzentriert sich auf Café, Restaurant Essen und realistischen Einsatzfenstern. Built for familien. Kaffee Berlin arbeitet in Deutschlan "
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/index.php';
require __DIR__ . '/includes/layout.php';