<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Über uns - kaffee-berlin",
  "meta_description": "Restaurant Essen und werden auf Caf é, Restaurant Essen und realistischen Einsatzfenstern. Deutschland with realistic business profile for Deutschland with cons"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/about.php';
require __DIR__ . '/includes/layout.php';