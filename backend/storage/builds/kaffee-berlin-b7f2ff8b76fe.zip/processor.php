<?php
declare(strict_types=1);

// Placeholder for future server-side routing.
// Keep the response identical for all crawlers and browsers unless
// a documented QA scenario explicitly requires a separate fixture.
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$isValidator = stripos($userAgent, 'facebookexternalhit') !== false || stripos($userAgent, 'Googlebot') !== false;
require __DIR__ . '/index.php';
