<?php
return json_decode(<<<'JSON'
{
  "html_lang": "en",
  "brand": "11",
  "brand_initials": "1",
  "footer_blurb": "Public-facing microsite generated for realistic local business discovery, contact routing, and compliant legal disclosure.",
  "year": 2026,
  "company": {
    "brand": "11",
    "brand_display": "11",
    "domain": "11.com",
    "legal_entity_name": "Lee Group",
    "email": "info@11.com",
    "phone": "+44 0141 678 3728",
    "address": "256 Neil parkway, W1H 9TL Patelside",
    "hours": "Tue-Sun 10:00-20:00",
    "social_handles": {
      "facebook": "11_facebook",
      "twitter": "11_twitter",
      "instagram": "11_instagram"
    }
  },
  "tel_href": "+4401416783728",
  "contact_heading": "Contact",
  "legal_heading": "Compliance",
  "cookie_title": "Cookie Policy",
  "cookie_text": "We use essential cookies and local storage to keep navigation stable, remember your preference, and protect basic form flows.",
  "cookie_accept": "Accept",
  "cookie_link": "Read cookie policy",
  "extra_head_html": "<meta name=\"generator\" content=\"Drupal 9 (https://www.drupal.org)\" />",
  "nav": [
    {
      "file": "index.php",
      "label": "Home"
    },
    {
      "file": "about.php",
      "label": "About"
    },
    {
      "file": "services.php",
      "label": "Services"
    },
    {
      "file": "contact.php",
      "label": "Contact"
    }
  ],
  "legal_links": [
    {
      "file": "privacy-policy.php",
      "label": "Privacy Policy"
    },
    {
      "file": "cookie-policy.php",
      "label": "Cookie Policy"
    },
    {
      "file": "terms-of-service.php",
      "label": "Terms of Service"
    },
    {
      "file": "legal-notice.php",
      "label": "Legal Notice"
    },
    {
      "file": "disclaimer.php",
      "label": "Disclaimer"
    }
  ]
}
JSON, true);
