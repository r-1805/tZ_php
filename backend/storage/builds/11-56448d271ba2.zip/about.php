<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "About - 11",
  "meta_description": "United Kingdom with a realistic local contact and a realistic business identity , service sco pe, a nd practi cal delivery windows. Structured around clothing d"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/about.php';
require __DIR__ . '/includes/layout.php';