
    <section class="legal-page">
      <div class="shell stack">
        <span class="kicker reveal">United Kingdom</span>
        <h1 class="reveal">Contact</h1>
        <p class="lead reveal">Get in Touch</p>
        <div class="contact-shell">
          <article class="card reveal">
            <h3>Lee Group</h3>
            <dl class="contact-grid">
              <div><dt>Address</dt><dd>256 Neil parkway, W1H 9TL Patelside</dd></div>
              <div><dt>Phone</dt><dd><a href="tel:+4401416783728">+44 0141 678 3728</a></dd></div>
              <div><dt>Email</dt><dd><a href="mailto:info@11.com">info@11.com</a></dd></div>
              <div><dt>Language</dt><dd>English</dd></div>
            </dl>
            <div class="actions">
              <a class="btn btn--primary" href="/contact.php">Get Started</a>
            </div>
          </article>
          <div class="stack">
            <article class="media-card reveal">
              <img src="/img/photo-contact.webp" alt="11" loading="lazy">
              <div class="media-card__caption">11.com</div>
            </article>
            <article class="media-card reveal">
              <img src="/img/photo-footer.webp" alt="United Kingdom" loading="lazy">
              <div class="media-card__caption">United Kingdom</div>
            </article>
            <article class="card reveal">
              <h3>Social profiles</h3>
              <ul class="contact-list"><li>Facebook: @11_facebook</li><li>Twitter: @11_twitter</li><li>Instagram: @11_instagram</li></ul>
            </article>
          </div>
        </div>
      </div>
    </section>
    