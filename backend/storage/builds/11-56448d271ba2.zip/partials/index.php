
    <section class="hero">
      <div class="shell hero__grid">
        <div class="hero__main reveal">
          <span class="kicker">United Kingdom</span>
          <h1>Clothing Design with a local profile</h1>
          <p class="lead">Stylish Outfits with consistent branding, reachable contact route and  consistent branding , reachable  contact data and consistent business information. Clothing Des ig  n, Fashion Retai l, and consistent business information.</p>
          <div class="actions">
            <a class="btn btn--primary" href="/contact.php">Get Started</a>
            <a class="btn btn--secondary" href="#services">Learn More</a>
          </div>
          <div class="tag-row"><span class='tag'><strong>36h</strong> Tue-Sun 10:00-20:00</span><span class='tag'><strong>7</strong> Fashion Lovers</span><span class='tag'><strong>96%</strong> Overview</span></div>
          <div class="metrics-band"><article class='metric-card reveal'><strong>36h</strong><span class='muted'>Tue-Sun 10:00-20:00</span></article><article class='metric-card reveal'><strong>7</strong><span class='muted'>Fashion Lovers</span></article><article class='metric-card reveal'><strong>96%</strong><span class='muted'>Overview</span></article></div>
        </div>
        <aside class="hero__support">
          <div class="media-card media-card--tall reveal">
            <img src="/img/photo-hero.jpg" alt="11" loading="lazy">
            <div class="media-card__caption">
              <strong>11</strong>
              <div>United Kingdom</div>
            </div>
          </div>
          <div class="panel reveal">
            <h3>Contact</h3>
            <dl class="contact-grid">
              <div><dt>Webadresse</dt><dd>11.com</dd></div>
              <div><dt>Email</dt><dd>info@11.com</dd></div>
              <div><dt>Phone</dt><dd>+44 0141 678 3728</dd></div>
              <div><dt>Address</dt><dd>256 Neil parkway, W1H 9TL Patelside</dd></div>
              <div><dt>Language</dt><dd>English</dd></div>
            </dl>
          </div>
        </aside>
      </div>
    </section>
    <section class="section section--spacious" id="services">
      <div class="shell">
        <div class="section__header">
          <span class="kicker section__eyebrow reveal">Why Choose Us</span>
          <h2>Why Choose Us</h2>
          <p class="lead">United Kingdom with a realistic local  contact and a realistic business identity , service sco pe, a nd practi cal delivery windows. Structured around clothing design and practical delivery wi ndow s. The public profile focuses on Clothing Design, Fashion Retail, and.</p>
        </div>
        <div class="grid-three">
            <article class="card reveal">
              <h3>Custom Apparel</h3>
              <p>Unique Designs</p>
            </article>
            
            <article class="card reveal">
              <h3>Clothing Design</h3>
              <p>Stylish Outfits</p>
            </article>
            
            <article class="card reveal">
              <h3>Fashion Retail</h3>
              <p>Quality Fabrics</p>
            </article>
            </div>
      </div>
    </section>
    <section class="section section--spacious">
      <div class="shell split-feature">
        <div class="stack reveal">
          <h2>Overview</h2>
          <p>United Kingdom with a realistic local  contact and a realistic business identity , service sco pe, a nd practi cal delivery windows. Structured around clothing design and practical delivery wi ndow s. The public profile focuses on Clothing Design, Fashion Retail, and.</p><p>11 serves Fashion Lovers across United Kingdom with an emphasis on realistic local operations and concise handoff notes.</p>
          <ul class="list-checks"><li>Custom Apparel</li><li>Clothing Design</li><li>Fashion Retail</li></ul>
        </div>
        <div class="gallery-strip">
          <div class="media-card reveal">
            <img src="/img/photo-gallery_primary.jpeg" alt="11" loading="lazy">
            <div class="media-card__caption">Lee Group</div>
          </div>
          <div class="media-card reveal">
            <img src="/img/photo-gallery_secondary.jpeg" alt="11" loading="lazy">
            <div class="media-card__caption">United Kingdom</div>
          </div>
          <div class="showcase-quote reveal">
            <h3>Contact</h3>
            <p>Get in Touch</p><p>Lee Group operates with local contact data, a consistent response window, and market-aware documentation for United Kingdom.</p>
            <div class="tag-row tag-row--footer"><span class='tag'>Lee Group</span><span class='tag'>256 Neil parkway, W1H 9TL Patelside</span><span class='tag'>Tue-Sun 10:00-20:00</span><span class='tag'>English · United Kingdom</span></div>
          </div>
        </div>
      </div>
    </section>
    <section class="section section--spacious">
      <div class="shell grid-two">
        <div class="panel reveal">
          <h2>Testimonials</h2>
          <div class="grid-three">
            <article class="card reveal">
              <h3>Morgan</h3>
              <p>Founder — We wanted something realistic and polished. 11 delivered exactly that.</p>
            </article>
            
            <article class="card reveal">
              <h3>Morgan</h3>
              <p>Studio coordinator — 11 keeps the experience structured, local, and easy to trust from first contact to delivery.</p>
            </article>
            
            <article class="card reveal">
              <h3>Cameron</h3>
              <p>Studio coordinator — The site makes the offer, contact path, and business identity feel consistent across every page.</p>
            </article>
            </div>
        </div>
        <div class="panel reveal">
          <h2>FAQ</h2>
          <div class="card"><div class='faq-item'><h3>How quickly can a new engagement start?</h3><p>We usually prepare the initial operating window within one working week once the scope and contacts are confirmed.</p></div><div class='faq-item'><h3>Do you adapt service windows to local schedules?</h3><p>Yes. Scheduling is planned around United Kingdom business hours, access constraints, and realistic response windows.</p></div><div class='faq-item'><h3>Can we request a custom scope before launch?</h3><p>Yes. The preview stage is designed to confirm scope, contact details, and documentation before export.</p></div><div class='faq-item'><h3>How are updates communicated after kickoff?</h3><p>Every engagement includes a single contact route, concise status notes, and a documented next-step list.</p></div></div>
        </div>
      </div>
    </section>
    <section class="shell reveal">
      <div class="cta-banner">
        <h2>11</h2>
        <p>Lee Group operates with local contact data, a consistent response window, and market-aware documentation for United Kingdom.</p>
        <div class="actions">
          <a class="btn btn--secondary" href="/contact.php">Get Started</a>
        </div>
      </div>
    </section>
    