
    <section class="legal-page">
      <div class="shell stack">
        <span class="kicker reveal">11</span>
        <h1 class="reveal">Services</h1>
        <div class="split-feature">
          <div class="stack reveal">
            <p class="lead">11 presents a structured set of categories so visitors can review the offer without needing external context.</p>
            <ul class="list-checks"><li>Custom Apparel</li><li>Clothing Design</li><li>Fashion Retail</li></ul>
          </div>
          <div class="media-card reveal">
            <img src="/img/photo-collection.jpg" alt="11" loading="lazy">
            <div class="media-card__caption">United Kingdom</div>
          </div>
        </div>
        <div class="grid-three">
            <article class="card reveal">
              <h3>01. Custom Apparel</h3>
              <p>Custom Apparel is delivered with defined milestones, market-aware wording, and realistic local coordination for United Kingdom.</p>
            </article>
            
            <article class="card reveal">
              <h3>02. Clothing Design</h3>
              <p>Clothing Design is delivered with defined milestones, market-aware wording, and realistic local coordination for United Kingdom.</p>
            </article>
            
            <article class="card reveal">
              <h3>03. Fashion Retail</h3>
              <p>Fashion Retail is delivered with defined milestones, market-aware wording, and realistic local coordination for United Kingdom.</p>
            </article>
            </div>
      </div>
    </section>
    