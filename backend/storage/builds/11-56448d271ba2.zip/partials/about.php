
    <section class="legal-page">
      <div class="shell stack">
        <span class="kicker reveal">Apparel</span>
        <h1 class="reveal">11</h1>
        <div class="split-feature">
          <div class="timeline">
            
        <article class="timeline__item reveal">
          <div class="timeline__step">01</div>
          <div class="card">
            <h3>11</h3>
            <p>United Kingdom with a realistic local  contact and a realistic business identity , service sco pe, a nd practi cal delivery windows. Structured around clothing design and practical delivery wi ndow s. The public profile focuses on Clothing Design, Fashion Retail, and.</p>
          </div>
        </article>
        
        <article class="timeline__item reveal">
          <div class="timeline__step">02</div>
          <div class="card">
            <h3>United Kingdom</h3>
            <p>The public offer that feels locally grounded  .  Every page keeps the business profile. United Kingd om with direct contact and transparent legal information.</p>
          </div>
        </article>
        
        <article class="timeline__item reveal">
          <div class="timeline__step">03</div>
          <div class="card">
            <h3>Lee Group</h3>
            <p>Clothing  Design, Fashion Retail, and a  realistic business identity, service  scope, and cl ea r. The site is designed around clothing design and a realistic business information.</p>
          </div>
        </article>
        
          </div>
          <div class="stack">
            <div class="media-card media-card--tall reveal">
              <img src="/img/photo-about.jpg" alt="11" loading="lazy">
              <div class="media-card__caption">Lee Group</div>
            </div>
            <div class="card reveal">
              <h3>Social profiles</h3>
              <ul class="contact-list"><li>Facebook: @11_facebook</li><li>Twitter: @11_twitter</li><li>Instagram: @11_instagram</li></ul>
            </div>
          </div>
        </div>
      </div>
    </section>
    