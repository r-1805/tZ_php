<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "11",
  "meta_description": "Stylish Outfits with consistent branding, reachable contact route and consistent branding , reachable contact data and consistent business information. Clothing"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/index.php';
require __DIR__ . '/includes/layout.php';