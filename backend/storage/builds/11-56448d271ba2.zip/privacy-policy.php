<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Privacy Policy - 11",
  "meta_description": "United Kingdom"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/privacy-policy.php';
require __DIR__ . '/includes/layout.php';