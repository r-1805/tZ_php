<?php
declare(strict_types=1);
$site = require __DIR__ . '/config/site.php';
$page = json_decode(<<<'JSON'
{
  "title": "Services - 11",
  "meta_description": "Custom Apparel, Clothing Design, Fashion Retail"
}
JSON, true);
$page['body_partial'] = __DIR__ . '/partials/services.php';
require __DIR__ . '/includes/layout.php';